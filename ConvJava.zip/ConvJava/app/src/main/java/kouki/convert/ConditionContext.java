package kouki.convert;

import kouki.convert.Node.SourceNode;

/**
 * condition(JavaScript条件式)から参照されるノード情報。
 * ロジックはすべてContextに共通実装されており、これは薄いサブクラス。
 */
public class ConditionContext extends Context {

    public ConditionContext(SourceNode node, TypeResolver typeResolver,
                             String methodScope, String classScope, TransformRuleActions actions) {
        super(node, typeResolver, methodScope, classScope, actions);
    }
}
