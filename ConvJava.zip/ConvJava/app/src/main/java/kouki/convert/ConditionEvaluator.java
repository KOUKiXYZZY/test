package kouki.convert;

import org.graalvm.polyglot.Value;

import java.util.Map;
import java.util.Optional;

/**
 * JavaScript条件式を評価するクラス。
 * GraalVM または 標準Java ScriptEngine（Nashorn）を使用
 */
public class ConditionEvaluator extends Evaluator {

    /**
     * JavaScript条件式を評価する
     * 
     * @param condition JavaScript式（例："ctx.getText().contains('getParameter')"）
     * @param ctx TransformationContext オブジェクト
     * @param bindings パターンマッチでキャプチャされた変数マップ
     * @return 評価結果（true/false）
     */
    public boolean condition(String condition, ConditionContext ctx, Map<String, String> bindings) {
        if (condition == null || condition.isBlank()) {
            return true;
        }
        
        try {
            putMember("ctx", ctx)
                .putMember("bindings", bindings);

            Optional<Value> optResult = evaluate(condition);

            return isTruthy(optResult.orElse(null));
        } catch (Exception e) {
            System.err.println("条件式の評価に失敗しました: " + condition);
            System.err.println("エラー: " + e.getMessage());
            return false;
        }
    }
    
}
