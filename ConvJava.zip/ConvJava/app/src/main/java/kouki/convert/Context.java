package kouki.convert;

import kouki.symboltable.java8.Java8Parser;
import kouki.convert.Node.SourceNode;

import java.util.ArrayList;
import java.util.List;

/**
 * condition/transformJs(JavaScript)から参照される、ノード情報の共通基底クラス。
 * ConditionContext/TransformationContextはどちらもこれを継承する。
 *
 * ANTLRのParserRuleContextを直接持たず、自作ノード(SourceNode)経由でアクセスする。
 * 呼び出しテキストの解析(引数抽出など)はSourceNode.getText()/getParent()/getChildText()
 * だけで完結するのでANTLR固有の型は不要。NormalClassDeclarationContext等の文法固有の
 * 詳細を辿る必要があるメソッド(getClassName等)だけは、SourceNode.raw()で元のANTLR
 * ノードに一時的にアクセスする。
 */
public abstract class Context {

    protected final SourceNode node;
    protected final TypeResolver typeResolver;
    protected final String methodScope;
    protected final String classScope;
    protected final TransformRuleActions actions;

    protected Context(SourceNode node, TypeResolver typeResolver,
                       String methodScope, String classScope, TransformRuleActions actions) {
        this.node = node;
        this.typeResolver = typeResolver;
        this.methodScope = methodScope;
        this.classScope = classScope;
        this.actions = actions;
    }

    public SourceNode getNode() {
        return node;
    }

    public String originalText() {
        return node.getText();
    }

    public String getText() {
        return node.getText();
    }

    public int getLine() {
        return node.getLine();
    }

    public String getNodeType() {
        return node.getNodeType();
    }

    /**
     * このノードを囲む最も近いクラス/インターフェース/enumの名前
     */
    public String getClassName() {
        SourceNode ctx = node;

        while (ctx != null) {
            var raw = ctx.raw();
            if (raw instanceof Java8Parser.NormalClassDeclarationContext c) {
                return c.Identifier().getText();
            }
            if (raw instanceof Java8Parser.NormalInterfaceDeclarationContext c) {
                return c.Identifier().getText();
            }
            if (raw instanceof Java8Parser.EnumDeclarationContext c) {
                return c.Identifier().getText();
            }
            ctx = ctx.getParent();
        }

        return null;
    }

    /**
     * このノードを囲む最も近いメソッドの名前
     */
    public String getMethodName() {
        SourceNode ctx = node;

        while (ctx != null) {
            if (ctx.raw() instanceof Java8Parser.MethodDeclarationContext m) {
                return m.methodHeader().methodDeclarator().Identifier().getText();
            }
            ctx = ctx.getParent();
        }

        return null;
    }

    /**
     * このノードを囲む最も近いメソッドのシグネチャ部分のテキスト
     */
    public String getMethodSignature() {
        SourceNode ctx = node;

        while (ctx != null) {
            if (ctx.raw() instanceof Java8Parser.MethodDeclarationContext m) {
                return m.methodHeader().methodDeclarator().getText();
            }
            ctx = ctx.getParent();
        }

        return null;
    }

    /**
     * メソッド呼び出しから引数のリストを抽出する。
     * "foo(a, b, c)" なら ["a", "b", "c"] を返す。
     */
    public List<String> extractArguments() {
        List<String> args = new ArrayList<>();
        String text = node.getText();

        int[] parens = findOutermostCallParens(text);
        if (parens == null) {
            return args;
        }
        int openParen = parens[0];
        int closeParen = parens[1];

        String argString = text.substring(openParen + 1, closeParen);
        if (argString.trim().isEmpty()) {
            return args;
        }

        // ジェネリクス等のネストを考慮してカンマで分割
        int depth = 0;
        StringBuilder current = new StringBuilder();
        for (char c : argString.toCharArray()) {
            if (c == '<' || c == '(') {
                depth++;
                current.append(c);
            } else if (c == '>' || c == ')') {
                depth--;
                current.append(c);
            } else if (c == ',' && depth == 0) {
                args.add(current.toString().trim());
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        if (current.length() > 0) {
            args.add(current.toString().trim());
        }

        return args;
    }

    /**
     * メソッド呼び出しからメソッド名を抽出する。
     * "obj.foo(...)" なら "foo" を返す。"foo(...)" なら "foo" を返す。
     * "obj.bar().foo(...)" のように呼び出しがネストしていても、末尾の呼び出し("foo")を返す。
     */
    public String extractMethodName() {
        String text = node.getText();
        int[] parens = findOutermostCallParens(text);
        if (parens == null) {
            return text;
        }

        String beforeParen = text.substring(0, parens[0]).trim();
        int lastDot = topLevelLastDot(beforeParen);

        if (lastDot >= 0) {
            return beforeParen.substring(lastDot + 1);
        }
        return beforeParen;
    }

    /**
     * レシーバー（ドット左側）を抽出する。
     * "obj.foo(...)" なら "obj" を返す。"foo(...)" なら null を返す。
     *
     * "this.foo(...)" のような呼び出しは、文法上 ".foo(...)" 部分だけが対象ノード
     * (methodInvocation_lf_primary)になり、"this" は親ノード側に属するためノード自身の
     * テキストにはレシーバーが含まれない。その場合は親ノードを遡ってレシーバー部分の
     * テキストを探す。
     */
    public String extractReceiver() {
        String receiver = extractReceiverFromOwnText();
        if (receiver != null && !receiver.isEmpty()) {
            return receiver;
        }
        // ".foo(...)" のように、ノード自身のテキストが'.'から始まる場合だけ
        // (= _lf_primary系の継続ノード)、レシーバーが親ノード側にあると判断して遡る。
        // "foo(...)" のような本当にレシーバーが無い呼び出しでは遡らない。
        if (node.getText().trim().startsWith(".")) {
            return extractReceiverFromAncestors();
        }
        return null;
    }

    private String extractReceiverFromOwnText() {
        String text = node.getText();
        int[] parens = findOutermostCallParens(text);
        if (parens == null) {
            return null;
        }

        String beforeParen = text.substring(0, parens[0]).trim();
        int lastDot = topLevelLastDot(beforeParen);

        if (lastDot >= 0) {
            return beforeParen.substring(0, lastDot);
        }
        return null;
    }

    /**
     * ノード自身のテキストにレシーバーが含まれない場合(例: methodInvocation_lf_primary)に、
     * 親ノードを遡って「このノードより前にある兄弟ノード」のテキストをレシーバーとして返す。
     * 兄弟が存在する祖先が見つかるまで遡り、見つからなければnullを返す。
     */
    private String extractReceiverFromAncestors() {
        SourceNode current = node;
        SourceNode parent = current.getParent();

        while (parent != null) {
            int index = indexOfChild(parent, current);
            if (index > 0) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < index; i++) {
                    sb.append(parent.getChildText(i));
                }
                String receiver = sb.toString();
                return receiver.isEmpty() ? null : receiver;
            }
            current = parent;
            parent = current.getParent();
        }
        return null;
    }

    private static int indexOfChild(SourceNode parent, SourceNode target) {
        for (int i = 0; i < parent.getChildCount(); i++) {
            if (parent.raw().getChild(i) == target.raw()) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 与えられた引数リストを使って、メソッド呼び出しを再構成する。
     */
    public String reconstructWithArguments(List<String> newArgs) {
        String text = node.getText();
        int[] parens = findOutermostCallParens(text);
        if (parens == null) {
            return text;
        }

        String before = text.substring(0, parens[0] + 1);
        String after = text.substring(parens[1]);
        String argString = String.join(", ", newArgs);

        return before + argString + after;
    }

    /**
     * このノードがメソッド呼び出し("obj.foo(...)")の場合、レシーバー("obj"部分)の型を
     * ベストエフォートで解決して返す。レシーバーが無い呼び出し("foo(...)")はthis扱いで
     * 現在のクラス名を返す。型が解決できない場合(外部ライブラリの型など)はnull。
     */
    public String getReceiverType() {
        if (typeResolver == null) {
            return null;
        }
        String receiver = extractReceiver();
        if (receiver == null) {
            return classScope == null ? null : getClassName();
        }
        return typeResolver.resolveExpressionType(receiver, methodScope, classScope);
    }

    /**
     * 任意の変数名/式の型をベストエフォートで解決する。
     */
    public String getVariableType(String expr) {
        if (typeResolver == null) {
            return null;
        }
        return typeResolver.resolveExpressionType(expr, methodScope, classScope);
    }

    public void addImport(String code) {
        if (actions != null) {
            actions.addImport(code);
        }
    }

    public void addClassMember(String code) {
        if (actions != null) {
            actions.addClassMember(code);
        }
    }

    public void addToMethod(String methodName, String code) {
        if (actions != null) {
            actions.addToMethod(methodName, code);
        }
    }

    public void addMethodIfMissing(String methodName, String methodSource) {
        if (actions != null) {
            actions.addMethodIfMissing(methodName, methodSource);
        }
    }

    /**
     * ノード自身のテキストの末尾の呼び出し("....foo(...)"の部分)に対応する
     * 開き括弧・閉じ括弧の位置を [openIndex, closeIndex] で返す。
     * "obj.bar().foo(a, b)" のようにネストした呼び出しを含むテキストでも、
     * 末尾の呼び出し(foo)の括弧を正しく見つけるため、最後の')'から深さを数えて
     * 対応する'('を探す(先頭から最初に見つかる'('を使うと、ネストした内側の
     * 呼び出しの括弧を誤って拾ってしまう)。
     */
    private static int[] findOutermostCallParens(String text) {
        int closeParen = text.lastIndexOf(')');
        if (closeParen < 0) {
            return null;
        }
        int depth = 0;
        for (int i = closeParen; i >= 0; i--) {
            char c = text.charAt(i);
            if (c == ')') {
                depth++;
            } else if (c == '(') {
                depth--;
                if (depth == 0) {
                    return new int[]{i, closeParen};
                }
            }
        }
        return null;
    }

    // ジェネリクス/括弧のネストを考慮して、トップレベル(深さ0)の最後の'.'を探す
    private static int topLevelLastDot(String s) {
        int depth = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == ')' || c == '>') {
                depth++;
            } else if (c == '(' || c == '<') {
                depth--;
            } else if (c == '.' && depth == 0) {
                return i;
            }
        }
        return -1;
    }
}
