package kouki.convert;

import org.graalvm.polyglot.Context;
import org.graalvm.polyglot.Value;
import org.graalvm.polyglot.proxy.ProxyExecutable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class Evaluator {
    private final Context context;

    {
        context = Context.newBuilder("js")
                .allowAllAccess(true) // ← これがないと、JavaオブジェクトをJS側で操作できない
                .build();
    }

    /**
     * JavaScript条件式を評価する
     * 
     * @param condition JavaScript式（例："ctx.getText().contains('getParameter')"）
     * @param ctx ConditionContext オブジェクト
     * @param bindings パターンマッチでキャプチャされた変数マップ
     * @return 評価結果（true/false）
     */
    protected Optional<Value> evaluate(String condition) {
        try {
            // JavaScriptエンジンのスコープに変数を追加
            synchronized (context) {
                Value result = context.eval("js", condition);

                return Optional.of(result);
            }
        } catch (Exception e) {
            System.err.println("条件式の評価に失敗しました: " + condition);
            System.err.println("エラー: " + e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * 
     * @return
     */
    protected Evaluator putMember(String identifier, Object value) {
        synchronized (context) {
            context.getBindings("js").putMember(identifier, value);
        }
        return this;
    }


    /**
     * GraalVMのValueをJavaScriptのtruthy/falsyのルールに沿ってbooleanに変換する。
     * null/undefined/0/空文字列などは偽、それ以外(boolean以外の値も含む)は真として扱う。
     */
    protected boolean isTruthy(Value result) {
        if (result == null || result.isNull()) {
            return false;
        }
        if (result.isBoolean()) {
            return result.asBoolean();
        }
        if (result.isNumber()) {
            double n = result.asDouble();
            return n != 0.0 && !Double.isNaN(n);
        }
        if (result.isString()) {
            return !result.asString().isEmpty();
        }
        // オブジェクト/関数など、それ以外の値は真として扱う
        return true;
    }

}
