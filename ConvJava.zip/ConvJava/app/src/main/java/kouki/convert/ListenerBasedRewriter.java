package kouki.convert;

import kouki.convert.Node.SourceNode;
import kouki.symboltable.java8.Java8Parser;
import kouki.symboltable.java8.Java8ParserBaseListener;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStreamRewriter;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * リスナーベースの構文木変換エンジン。
 * ListenerRule を使って、条件にマッチしたノードに対して変換操作を適用する。
 *
 * 前提コードの挿入は RuleActions インターフェースとして実装されており、
 * ルール表の固定列(importPrerequisite等)からだけでなく、transformJs自身からも
 * ctx.addImport(...)等を通じて同じ仕組みを呼び出せる。
 */
public class ListenerBasedRewriter extends Java8ParserBaseListener implements TransformRuleActions {

    private final TokenStreamRewriter rewriter;
    private final List<ListenerRule> rules;
    private final TypeResolver typeResolver;
    private final ConditionEvaluator conditionEvaluator = new ConditionEvaluator();
    private final TransformationEvaluator transformationEvaluator = new TransformationEvaluator();

    // 同じノードに複数のrewriterを指定しないようにするため、既に変換済みのノードを追跡
    private final Set<Integer> transformedNodes = new HashSet<>();

    // メソッドスタック（前提コード挿入用）
    private final Deque<Java8Parser.MethodDeclarationContext> methodStack = new ArrayDeque<>();
    private final Map<Java8Parser.MethodDeclarationContext, Set<String>> insertedMethodPrerequisites = new HashMap<>();

    // クラススタック（前提コード挿入用。NormalClassDeclarationのみ対応）
    private final Deque<Java8Parser.NormalClassDeclarationContext> classStack = new ArrayDeque<>();
    private final Map<Java8Parser.NormalClassDeclarationContext, Set<String>> insertedClassPrerequisites = new HashMap<>();
    // addMethodIfMissingで追加済みのメソッド名(クラスごと)。一度追加したら同じ名前は二度と追加しない
    private final Map<Java8Parser.NormalClassDeclarationContext, Set<String>> addedMethodNames = new HashMap<>();
    // addMethodIfMissingで新規作成中のメソッド(クラスごと、メソッド名ごと)。構文木上には存在しない
    // (テキストとしてまだ挿入されていない)ため、addToMethod()で後から見つけられるようにここで保持し、
    // クラスを抜けるタイミングでまとめてrewriterに反映する。
    private final Map<Java8Parser.NormalClassDeclarationContext, Map<String, PendingMethod>> pendingNewMethods = new HashMap<>();

    // 新規作成中のメソッドのソースと、既に追記済みのコード(重複追記を防ぐため)を保持する
    private static class PendingMethod {
        final StringBuilder source;
        final Set<String> insertedCodes = new HashSet<>();

        PendingMethod(String initialSource) {
            this.source = new StringBuilder(initialSource);
        }
    }

    // SymbolTableListenerと同じ考え方のスコープスタック(レシーバ型解決に使う)
    private final Deque<String> scope = new ArrayDeque<>();
    private final Deque<String> classScopeStack = new ArrayDeque<>();

    // ファイル先頭への前提コード挿入用(import文など。ファイルにつき1回)
    private Token fileStartToken;
    private Token afterPackageDeclarationToken;
    private final Set<String> insertedFilePrerequisites = new HashSet<>();

    // ルールがどの箇所(行+列)に既に適用されたかを、パスをまたいで記録する。
    // SourceConverterのマルチパス変換では、呼び出し系ルールが1回目・3回目の両方の
    // 対象になり得るため、これが無いと宣言変更を必要としないルールが2回とも一致して
    // 二重適用されてしまう(呼び出しはパスごとに再パースされ、ノードの同一性が
    // 保証できないため、行+列という位置情報で同一箇所とみなす)。
    private final Set<String> appliedRuleSites;

    public ListenerBasedRewriter(TokenStreamRewriter rewriter, List<ListenerRule> rules) {
        this(rewriter, rules, null);
    }

    public ListenerBasedRewriter(TokenStreamRewriter rewriter, List<ListenerRule> rules, TypeResolver typeResolver) {
        this(rewriter, rules, typeResolver, new HashSet<>());
    }

    public ListenerBasedRewriter(TokenStreamRewriter rewriter, List<ListenerRule> rules, TypeResolver typeResolver,
                                  Set<String> appliedRuleSites) {
        this.rewriter = rewriter;
        this.rules = rules;
        this.typeResolver = typeResolver;
        this.appliedRuleSites = appliedRuleSites != null ? appliedRuleSites : new HashSet<>();
    }

    private String currentScope() {
        return String.join(".", scope);
    }

    private void pushScope(String name) {
        scope.addLast(name);
    }

    private void popScope() {
        scope.removeLast();
    }

    private String currentClassScope() {
        return classScopeStack.peekLast();
    }

    @Override
    public void enterCompilationUnit(Java8Parser.CompilationUnitContext ctx) {
        fileStartToken = ctx.getStart();
    }

    @Override
    public void enterPackageDeclaration(Java8Parser.PackageDeclarationContext ctx) {
        pushScope(ctx.packageName().getText());
        afterPackageDeclarationToken = ctx.getStop();
    }

    @Override
    public void enterNormalClassDeclaration(Java8Parser.NormalClassDeclarationContext ctx) {
        pushScope(ctx.Identifier().getText());
        classScopeStack.addLast(currentScope());
        classStack.addLast(ctx);
        tryApplyRules(ctx);  // NormalClassDeclarationContext に対するルールを適用
    }

    @Override
    public void exitNormalClassDeclaration(Java8Parser.NormalClassDeclarationContext ctx) {
        flushPendingNewMethods(ctx);
        classStack.removeLast();
        classScopeStack.removeLast();
        popScope();
    }

    @Override
    public void enterNormalInterfaceDeclaration(Java8Parser.NormalInterfaceDeclarationContext ctx) {
        pushScope(ctx.Identifier().getText());
        classScopeStack.addLast(currentScope());
    }

    @Override
    public void exitNormalInterfaceDeclaration(Java8Parser.NormalInterfaceDeclarationContext ctx) {
        classScopeStack.removeLast();
        popScope();
    }

    @Override
    public void enterEnumDeclaration(Java8Parser.EnumDeclarationContext ctx) {
        pushScope(ctx.Identifier().getText());
        classScopeStack.addLast(currentScope());
    }

    @Override
    public void exitEnumDeclaration(Java8Parser.EnumDeclarationContext ctx) {
        classScopeStack.removeLast();
        popScope();
    }

    @Override
    public void enterMethodDeclaration(Java8Parser.MethodDeclarationContext ctx) {
        methodStack.addLast(ctx);
        pushScope(ctx.methodHeader().methodDeclarator().Identifier().getText());
        tryApplyRules(ctx);  // MethodDeclarationContext に対するルールを適用
    }

    @Override
    public void exitMethodDeclaration(Java8Parser.MethodDeclarationContext ctx) {
        popScope();
        methodStack.removeLast();
    }

    @Override
    public void enterInterfaceMethodDeclaration(Java8Parser.InterfaceMethodDeclarationContext ctx) {
        pushScope(ctx.methodHeader().methodDeclarator().Identifier().getText());
        tryApplyRules(ctx);
    }

    @Override
    public void exitInterfaceMethodDeclaration(Java8Parser.InterfaceMethodDeclarationContext ctx) {
        popScope();
    }

    @Override
    public void enterConstructorDeclaration(Java8Parser.ConstructorDeclarationContext ctx) {
        pushScope(ctx.constructorDeclarator().simpleTypeName().getText());
        tryApplyRules(ctx);
    }

    @Override
    public void exitConstructorDeclaration(Java8Parser.ConstructorDeclarationContext ctx) {
        popScope();
    }

    @Override
    public void enterMethodInvocation(Java8Parser.MethodInvocationContext ctx) {
        tryApplyRules(ctx);
    }

    @Override
    public void enterMethodInvocation_lfno_primary(Java8Parser.MethodInvocation_lfno_primaryContext ctx) {
        tryApplyRules(ctx);
    }

    @Override
    public void enterMethodInvocation_lf_primary(Java8Parser.MethodInvocation_lf_primaryContext ctx) {
        tryApplyRules(ctx);
    }

    @Override
    public void enterPrimary(Java8Parser.PrimaryContext ctx) {
        tryApplyRules(ctx);
    }

    @Override
    public void enterExpression(Java8Parser.ExpressionContext ctx) {
        tryApplyRules(ctx);
    }

    @Override
    public void enterStatement(Java8Parser.StatementContext ctx) {
        tryApplyRules(ctx);
    }

    /**
     * 与えられたノードに対して、ルールの条件をチェックして変換を適用する
     */
    private void tryApplyRules(ParserRuleContext rawCtx) {
        String nodeTypeName = rawCtx.getClass().getSimpleName();

        // ノードの一意識別子（メモリアドレスを使用）
        int nodeId = System.identityHashCode(rawCtx);

        // 既に変換済みのノードならスキップ
        if (transformedNodes.contains(nodeId)) {
            return;
        }

        // 親ノードが既に変換済みの場合（子ノードの範囲が親に含まれる）スキップ
        ParserRuleContext parent = rawCtx.getParent();
        while (parent != null) {
            if (transformedNodes.contains(System.identityHashCode(parent))) {
                // 親が既に変換済みなら、子ノードの置換スキップ
                return;
            }
            parent = parent.getParent();
        }

        // ANTLRのノードは一度だけSourceNodeに包み、以降はこのSourceNode経由で扱う
        SourceNode node = new SourceNode(rawCtx);

        for (ListenerRule rule : rules) {
            // ノード型がマッチするか確認
            if (!nodeTypeName.contains(rule.targetNodeType())) {
                continue;
            }

            // このルールが既に(別パスで)同じ箇所に適用済みならスキップする。
            // 列番号は使わない: このルール自身の変換がノードの開始位置の直前にテキストを
            // 挿入すると(コメントを付け足す等)、次のパスで再レックスした時に同じ呼び出しの
            // 開始トークンの列がずれてしまい、列を含めると別の場所だと誤判定してしまうため。
            String siteKey = rule.id() + "@line" + node.getStartToken().getLine();
            if (appliedRuleSites.contains(siteKey)) {
                continue;
            }

            ConditionContext conditionCtx = new ConditionContext(
                    node, typeResolver, currentScope(), currentClassScope(), this);

            boolean condition = conditionEvaluator.condition(
                    rule.condition(),
                    conditionCtx,
                    new HashMap<>()  // バインディング（必要に応じて拡張）
            );

            if (!condition) {
                continue;
            }

            TransformationContext transformCtx = new TransformationContext(
                    node, typeResolver, currentScope(), currentClassScope(), this);

            // 条件が真なら変換を実行する。失敗した場合はこのノードへの適用をスキップする
            // (transformJs内でctx.addImport(...)等が呼ばれていれば、その時点で既に挿入は実行されている)
            boolean applied = applyTransformation(rule, transformCtx);
            if (!applied) {
                continue;
            }

            // 重要: 同じノードに対して複数のrewriter.replace()が指定された場合、
            // 最後のものが勝つため、テキスト置換ルールが一度適用されたら、
            // このノードに対してはそれ以上のテキスト置換をスキップする。
            // 前提コード挿入（addImport等）は引き続き実行される。
            transformedNodes.add(nodeId);
            appliedRuleSites.add(siteKey);
            break;
        }
    }

    /**
     * ルールの変換用JavaScriptを実行し、結果でノードを置き換える。成功したらtrueを返す。
     */
    private boolean applyTransformation(ListenerRule rule, TransformationContext ctx) {
        String result = transformationEvaluator.transform(rule.transformJs(), ctx, new HashMap<>(), this);
        if (result == null) {
            System.err.println("ルール " + rule.id() + " の変換に失敗したためスキップしました");
            return false;
        }

        SourceNode node = ctx.getNode();
        rewriter.replace(node.getStartToken(), node.getStopToken(), result);
        return true;
    }

    // ===== RuleActions実装(transformJsのctxからも、ルール表の固定列からも呼ばれる) =====

    @Override
    public void addImport(String code) {
        if (code == null || code.isBlank()) {
            return;
        }
        // 既に同じ前提コードを挿入済みなら何もしない
        if (insertedFilePrerequisites.contains(code)) {
            return;
        }
        insertedFilePrerequisites.add(code);

        if (afterPackageDeclarationToken != null) {
            rewriter.insertAfter(afterPackageDeclarationToken, "\n" + code);
        } else {
            rewriter.insertBefore(fileStartToken, code + "\n");
        }
    }

    @Override
    public void addClassMember(String code) {
        if (code == null || code.isBlank()) {
            return;
        }
        if (classStack.isEmpty()) {
            System.err.println("addClassMember()は、クラスの外では呼べません: " + code);
            return;
        }
        insertClassMember(classStack.peekLast(), code);
    }

    @Override
    public void addToMethod(String methodName, String code) {
        if (code == null || code.isBlank()) {
            return;
        }
        if (classStack.isEmpty()) {
            System.err.println("addToMethod()は、クラスの外では呼べません: " + methodName);
            return;
        }
        Java8Parser.NormalClassDeclarationContext currentClass = classStack.peekLast();

        // 構文木に既にあるメソッドなら、そちらにrewriterで直接挿入する
        Java8Parser.MethodDeclarationContext method = findMethodInClass(currentClass, methodName);
        if (method != null) {
            insertMethodBody(method, code);
            return;
        }

        // addMethodIfMissing()でこのクラスに新規作成中(まだテキスト化されていない)メソッドなら、
        // そのバッファに直接コードを追記する
        Map<String, PendingMethod> pending = pendingNewMethods.get(currentClass);
        PendingMethod pendingMethod = pending == null ? null : pending.get(methodName);
        if (pendingMethod != null) {
            // 既に同じコードを追記済みなら何もしない(insertMethodBodyと同じ重複排除)
            if (pendingMethod.insertedCodes.add(code)) {
                appendCodeIntoMethodSource(pendingMethod.source, code);
            }
            return;
        }

        System.err.println("addToMethod(): メソッド " + methodName
                + " が現在のクラスに見つからないため、コードを挿入できません"
                + "(先に addMethodIfMissing() で作成してください)");
    }

    @Override
    public void addMethodIfMissing(String methodName, String methodSource) {
        if (methodSource == null || methodSource.isBlank()) {
            return;
        }
        if (classStack.isEmpty()) {
            System.err.println("addMethodIfMissing()は、クラスの外では呼べません: " + methodName);
            return;
        }

        Java8Parser.NormalClassDeclarationContext currentClass = classStack.peekLast();
        Set<String> added = addedMethodNames.computeIfAbsent(currentClass, k -> new HashSet<>());
        if (added.contains(methodName)) {
            // 既に追加済み、または元から存在するとして扱い済み
            return;
        }
        added.add(methodName);

        if (findMethodInClass(currentClass, methodName) != null) {
            // 既存のメソッドがあるので、新規作成はしない
            return;
        }

        if (currentClass.classBody() == null) {
            System.err.println("メソッド " + methodName + " の追加は、本体のないクラスにはできません");
            return;
        }

        // すぐにはrewriterへ反映せず、クラスを抜けるまでバッファに保持する。
        // こうすることで、後から呼ばれるaddToMethod(methodName, ...)がこのバッファに
        // コードを追記できる(構文木には存在しないメソッドなので、木を辿る方法では見つけられないため)。
        pendingNewMethods.computeIfAbsent(currentClass, k -> new HashMap<>())
                .put(methodName, new PendingMethod(methodSource));
    }

    /**
     * 新規作成中のメソッドのソース文字列(末尾は閉じ括弧 '}' で終わっている想定)に、
     * 最後の '}' の直前にコードを挿入する形で追記する。
     */
    private void appendCodeIntoMethodSource(StringBuilder methodSource, String code) {
        int lastBrace = methodSource.lastIndexOf("}");
        if (lastBrace < 0) {
            // 想定外の形式(閉じ括弧が無い)。末尾にそのまま足す
            methodSource.append("\n").append(code);
            return;
        }
        methodSource.insert(lastBrace, "        " + code + "\n    ");
    }

    /**
     * クラスを抜けるタイミングで、addMethodIfMissing()でバッファに溜めておいた
     * 新規メソッドをまとめてrewriterに反映する(クラス本体の閉じ括弧の直前に挿入)。
     */
    private void flushPendingNewMethods(Java8Parser.NormalClassDeclarationContext classCtx) {
        Map<String, PendingMethod> pending = pendingNewMethods.remove(classCtx);
        if (pending == null || pending.isEmpty()) {
            return;
        }
        Java8Parser.ClassBodyContext classBody = classCtx.classBody();
        if (classBody == null) {
            return;
        }
        for (PendingMethod pendingMethod : pending.values()) {
            rewriter.insertBefore(classBody.getStop(), "\n    " + pendingMethod.source + "\n");
        }
    }

    /**
     * ルール表のmethodPrerequisite列(現在のメソッドが対象)用のヘルパー。
     * addToMethod(name, code)と違い、対象は「いま処理中のメソッド」固定。
     */
    private void addToCurrentMethod(String code) {
        if (code == null || code.isBlank()) {
            return;
        }
        if (methodStack.isEmpty()) {
            System.err.println("メソッド前提コードは、メソッドの外では挿入できません: " + code);
            return;
        }
        insertMethodBody(methodStack.peekLast(), code);
    }

    private void insertClassMember(Java8Parser.NormalClassDeclarationContext classCtx, String code) {
        Set<String> inserted = insertedClassPrerequisites.computeIfAbsent(classCtx, k -> new HashSet<>());
        if (inserted.contains(code)) {
            return;
        }
        inserted.add(code);

        Java8Parser.ClassBodyContext classBody = classCtx.classBody();
        if (classBody == null) {
            System.err.println("クラスメンバーの追加は、本体のないクラスにはできません: " + code);
            return;
        }
        // クラス本体の開き括弧 '{' の直後に挿入
        rewriter.insertAfter(classBody.getStart(), "\n    " + code);
    }

    private void insertMethodBody(Java8Parser.MethodDeclarationContext methodCtx, String code) {
        Set<String> inserted = insertedMethodPrerequisites.computeIfAbsent(methodCtx, k -> new HashSet<>());
        if (inserted.contains(code)) {
            return;
        }
        inserted.add(code);

        Java8Parser.MethodBodyContext methodBody = methodCtx.methodBody();
        if (methodBody == null || methodBody.block() == null) {
            System.err.println("メソッド本体へのコード挿入は、本体のないメソッドにはできません: " + code);
            return;
        }
        // メソッド本体の開き括弧 '{' の直後に挿入
        rewriter.insertAfter(methodBody.block().getStart(), "\n        " + code);
    }

    /**
     * 指定したクラスの直下から(ネストしたクラスは見ない)、指定した名前のメソッドを探す。
     * 見つからなければnull。
     */
    private Java8Parser.MethodDeclarationContext findMethodInClass(
            Java8Parser.NormalClassDeclarationContext classCtx, String methodName) {
        if (classCtx.classBody() == null) {
            return null;
        }
        for (Java8Parser.ClassBodyDeclarationContext bodyDecl : classCtx.classBody().classBodyDeclaration()) {
            if (bodyDecl.classMemberDeclaration() == null) {
                continue;
            }
            Java8Parser.MethodDeclarationContext methodDecl = bodyDecl.classMemberDeclaration().methodDeclaration();
            if (methodDecl == null) {
                continue;
            }
            String name = methodDecl.methodHeader().methodDeclarator().Identifier().getText();
            if (name.equals(methodName)) {
                return methodDecl;
            }
        }
        return null;
    }
}
