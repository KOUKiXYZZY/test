package kouki.convert;

/**
 * リスナーベースの変換ルール。
 * 条件(JavaScript)と、その条件にマッチした際に実行する変換(JavaScript)を保持する。
 *
 * 前提コードは挿入位置ごとに別々の列に分かれている(importPrerequisite / classPrerequisite /
 * methodPrerequisite)。これにより、1つのルールで「importを追加しつつクラスにフィールドも
 * 追加する」のように複数の挿入位置を同時に指定できる(以前はprerequisite+insertPositionの
 * 組が1つしか持てず、importとCLASS_STARTを両方やりたい場合にルールを2つに分ける必要があった)。
 */
public record ListenerRule(
        String id,
        String targetNodeType,          // 対象ノード型（例："MethodInvocationContext"）
        String condition,               // JavaScript 条件式（例："ctx.getText().contains('getParameter')"）
        String transformJs             // 変換用のJavaScript関数(例: "function transform(ctx, bindings) { ... return ...; }")
) {
    /**
     * ビルダーパターンでの生成を簡単にするためのヘルパークラス
     */
    public static class Builder {
        private String id;
        private String targetNodeType;
        private String condition;
        private String transformJs;

        public Builder id(String id) {
            this.id = id;
            return this;
        }

        public Builder targetNodeType(String nodeType) {
            this.targetNodeType = nodeType;
            return this;
        }

        public Builder condition(String condition) {
            this.condition = condition;
            return this;
        }

        public Builder transformJs(String transformJs) {
            this.transformJs = transformJs;
            return this;
        }

        public ListenerRule build() {
            return new ListenerRule(id, targetNodeType, condition, transformJs);
        }
    }
}
