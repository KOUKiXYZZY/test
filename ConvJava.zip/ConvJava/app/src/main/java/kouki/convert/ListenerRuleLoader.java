package kouki.convert;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * ListenerRule ベースのルール表(.xlsx)を読み込むクラス。
 * 列構成（0-indexed）：
 *   0: id - ルールID
 *   1: targetNodeType - 対象ノード型（例："MethodInvocationContext"）
 *   2: condition - JavaScript条件式（例："ctx.getText().contains('getParameter')"）
 *   3: transformJs - 変換用のJavaScript関数
 *        例: "function transform(ctx, bindings) { return ctx.extractReceiver() + '.getAttribute(...)'; }"
 *   4: importPrerequisite - ファイルの先頭に挿入する前提コード（オプション。import文など）
 *   5: classPrerequisite - 現在のクラス本体の先頭に挿入する前提コード（オプション。フィールド宣言など）
 *   6: methodPrerequisite - 現在のメソッド本体の先頭に挿入する前提コード（オプション。ローカル変数宣言など）
 *
 * 4〜6は同時に複数指定できる(例: importとクラスフィールドを同じルールで一緒に追加する)。
 */
public class ListenerRuleLoader {

    private static final DataFormatter FORMATTER = new DataFormatter();

    public static List<ListenerRule> load(String xlsxPath) throws IOException {
        List<ListenerRule> rules = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(xlsxPath);
             XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);

            // rowNum=0 はヘッダー行なので1から開始
            for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
                Row row = sheet.getRow(rowNum);
                if (row == null || isBlank(getCellText(row, 1))) {
                    // targetNodeType列が空の行はスキップ
                    continue;
                }

                String id = getCellText(row, 0);
                String targetNodeType = getCellText(row, 1);
                String condition = getCellText(row, 2);
                String transformJs = getCellText(row, 3);

                if (isBlank(transformJs)) {
                    System.err.println("警告：ルール " + id + " に変換用のJavaScript(transformJs)がありません");
                    continue;
                }

                ListenerRule rule = new ListenerRule(
                        id,
                        targetNodeType,
                        condition.isEmpty() ? "true" : condition,
                        transformJs
                );

                rules.add(rule);
            }
        }

        return rules;
    }

    private static String getCellText(Row row, int columnIndex) {
        Cell cell = row.getCell(columnIndex);
        if (cell == null) {
            return "";
        }
        return FORMATTER.formatCellValue(cell).trim();
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
