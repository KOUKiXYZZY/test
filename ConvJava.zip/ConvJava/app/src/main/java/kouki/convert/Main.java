package kouki.convert;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * リスナーベースのルール表(.xlsx)を読み込み、指定したJavaファイルに適用して 
 * 標準出力(または出力先ファイル)に書き出すCLI
 */
public class Main {

    public static void usage() {
        System.err.println("Usage: AppletToServletConverter <source.java> <rules.xlsx> [output.java] [symbols.db]");
        System.err.println("  symbols.db: optional. Pre-built via './gradlew symboltable'. Used as a fallback");
        System.err.println("              for receiver type resolution (e.g. ctx.getReceiverType()) when the");
        System.err.println("              type isn't defined in the file being converted.");
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 2) {
            usage();
            System.exit(1);
        }

        Path sourceFile = Path.of(args[0]);
        String rulesXlsxPath = args[1];
        String symbolsDbPath = args.length >= 3 ? args[2] : null;
        String outputPath = args.length >= 4 ? args[3] : null;

        // リスナーベースのルール表を読み込み
        List<ListenerRule> rules = ListenerRuleLoader.load(rulesXlsxPath);
        System.out.println("Loaded " + rules.size() + " listener rule(s) from " + rulesXlsxPath);

        // リスナーベースの変換エンジンで処理
        String converted = SourceConverter.convert(sourceFile, rules, symbolsDbPath);
        if (outputPath != null) {
            Path outputFile = Path.of(outputPath);
            Files.writeString(outputFile, converted, StandardCharsets.UTF_8);
            System.out.println("Wrote converted source to " + outputFile);
        } else {
            System.out.println(converted);
        }
    }
}
