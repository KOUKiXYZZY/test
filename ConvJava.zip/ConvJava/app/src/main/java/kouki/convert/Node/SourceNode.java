package kouki.convert.Node;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.ParseTree;

/**
 * ANTLRのParserRuleContextをラップする自作ノード。
 *
 * condition/transformJs(JavaScript)や変換ロジックからは、ANTLR固有の型
 * (ParserRuleContext)を直接触らせず、この SourceNode を経由してアクセスさせる。
 * こうすることで、条件式・変換ロジック側はANTLRの詳細(木の構造やAPI)から切り離される。
 *
 * ただし、木を実際に辿る/書き換える(TokenStreamRewriterに渡す等)ためには最終的に
 * ParserRuleContextが必要になるため、raw()で元のノードへのエスケープハッチを用意している。
 * raw()はkouki.convertパッケージ内部の実装(TransformationContext/ListenerBasedRewriter等)
 * からのみ使う想定で、JS側には公開しない。
 */
public class SourceNode {

    private final ParserRuleContext ctx;

    public SourceNode(ParserRuleContext ctx) {
        this.ctx = ctx;
    }

    /** ノードの元のソーステキスト */
    public String getText() {
        return ctx.getText();
    }

    /** ノードのクラス名(例: "MethodInvocationContext") */
    public String getNodeType() {
        return ctx.getClass().getSimpleName();
    }

    /** ノードの開始行番号 */
    public int getLine() {
        return ctx.getStart().getLine();
    }

    /** ノードの開始/終了トークン(TokenStreamRewriterでの書き換えに使う) */
    public Token getStartToken() {
        return ctx.getStart();
    }

    public Token getStopToken() {
        return ctx.getStop();
    }

    /** 親ノード(SourceNodeとして)。親が無ければnull */
    public SourceNode getParent() {
        return (ctx.getParent() instanceof ParserRuleContext p) ? new SourceNode(p) : null;
    }

    public int getChildCount() {
        return ctx.getChildCount();
    }

    /** i番目の子ノードのテキスト(子がParserRuleContextでない終端記号でも取得できる) */
    public String getChildText(int i) {
        ParseTree child = ctx.getChild(i);
        return child == null ? "" : child.getText();
    }

    public boolean isSameNodeAs(SourceNode other) {
        return other != null && this.ctx == other.ctx;
    }

    /**
     * 元のANTLRノードへのエスケープハッチ。文法固有の詳細(特定の宣言の子要素を取り出す等)
     * を扱う内部実装からのみ使うこと。JS側や条件式には公開しない。
     */
    public ParserRuleContext raw() {
        return ctx;
    }
}
