package kouki.convert;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * AppletToServlet変換用のサンプルルール表を生成するユーティリティ
 */
public class SampleRuleTableGenerator {

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.err.println("Usage: SampleRuleTableGenerator <output.xlsx>");
            System.exit(1);
        }

        String outputPath = args[0];
        generateSampleRules(outputPath);
        System.out.println("Generated sample rules to: " + outputPath);
    }

    public static void generateSampleRules(String outputPath) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Rules");

        // ヘッダー行
        Row headerRow = sheet.createRow(0);
        String[] headers = {
            "id",
            "targetNodeType",
            "condition",
            "transformJs",
            "importPrerequisite",
            "classPrerequisite",
            "methodPrerequisite"
        };
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }

        // ルール1: getParameter() をリネーム
        int rowNum = 1;
        addRule(sheet, rowNum++,
            "rule_getParameter",
            "MethodInvocation",  // Match all MethodInvocation node types (including variants)
            "ctx.getText().includes('getParameter')",
            "function transform(ctx, bindings) {\n"
                + "    return ctx.originalText().replace(ctx.extractMethodName(), 'getAttribute');\n"
                + "}",
            "",
            "",
            "HttpServletRequest request;"
        );



        // ルール5: getParameter()呼び出しがあるクラスに、サーブレットでよく使うimport文と
        // フィールドを1行で同時に追加する例(importPrerequisite + classPrerequisiteの併用)。
        // 以前はIMPORT用とCLASS_START用でルールを2つに分ける必要があったが、
        // 前提コードの列を挿入位置ごとに分けたことで1ルールにまとめられる。
        addRule(sheet, rowNum++,
            "rule_add_request_field",
            "MethodInvocation_lfno_primaryContext",
            "ctx.getText().includes('getParameter')",
            "function transform(ctx, bindings) {\n"
                + "    return ctx.originalText();\n"
                + "}",
            "import javax.servlet.http.HttpServletRequest;",
            "private HttpServletRequest request;",
            ""
        );

        // ルール6: レシーバの型を見てJSの分岐を切り替える例(ctx.getReceiverType()の利用例)。
        // "getParameter(...)"(暗黙のthis)も"this.getParameter(...)"(明示的なthis)も
        // どちらもgetReceiverType()は現在のクラス名(SampleApplet)を返す。
        addRule(sheet, rowNum++,
            "rule_mark_implicit_this_calls",
            "MethodInvocation",
            "ctx.getText().includes('getParameter') && ctx.getReceiverType() === 'SampleApplet'",
            "function transform(ctx, bindings) {\n"
                + "    return '/* implicit-this on ' + ctx.getReceiverType() + ' */ ' + ctx.originalText();\n"
                + "}",
            "",
            "",
            ""
        );

        // ルール7: symbols.dbをフォールバックに使った、ファイルをまたいだ型解決の例。
        // samples/UseDog.java の "d.describe().length()" を変換対象とする。
        // "d.describe()" の型(String)は、Dogクラス自体がUseDog.javaとは別ファイル
        // (samples/Animal.java)で定義されているため、変換対象ファイル単体のシンボルテーブルでは
        // 解決できない。事前に ./gradlew symboltable --args="samples symbols.db" で
        // プロジェクト全体のシンボルテーブルを作っておき、convertタスクの4番目の引数として
        // symbols.dbを渡すことで初めて解決できる。
        // なお、symbols.db経由で取れる型はFQCN解決済み("java.lang.String")になることがあるため、
        // 単純名との完全一致ではなく endsWith で比較している。
        addRule(sheet, rowNum++,
            "rule_cross_file_chain_resolution",
            "MethodInvocationContext",
            "ctx.getText().includes('.length(') && ctx.getReceiverType() !== null && ctx.getReceiverType().endsWith('String')",
            "function transform(ctx, bindings) {\n"
                + "    return '/* receiver resolved via symbols.db: ' + ctx.getReceiverType() + ' */' + ctx.originalText();\n"
                + "}",
            "",
            "",
            ""
        );

        // ルール8: transformJs内からctx.addImport()/addMethodIfMissing()/addToMethod()を
        // 直接呼び出す例。ルール表の固定列(importPrerequisite等)と違い、
        //   - importは条件付きで追加できる(ここではgetReceiverType()がSampleAppletの時だけ)
        //   - 対象メソッドを名前で指定できる("destroy"。今いるメソッドがinit/paintでも関係ない)
        //   - 指定したメソッドが無ければ作成してから挿入できる
        addRule(sheet, rowNum++,
            "rule_ensure_destroy_cleanup",
            "MethodInvocation_lfno_primaryContext",
            "ctx.getText().includes('getParameter')",
            "function transform(ctx, bindings) {\n"
                + "    if (ctx.getReceiverType() === 'SampleApplet') {\n"
                + "        ctx.addImport('import java.util.logging.Logger;');\n"
                + "    }\n"
                + "    ctx.addMethodIfMissing('destroy', 'public void destroy() {\\n    }');\n"
                + "    ctx.addToMethod('destroy', 'System.out.println(\"destroyed\");');\n"
                + "    return ctx.originalText();\n"
                + "}",
            "",
            "",
            ""
        );

        // 列幅を自動調整
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // ファイルに保存
        try (FileOutputStream fos = new FileOutputStream(outputPath)) {
            workbook.write(fos);
        }
        workbook.close();
    }

    private static void addRule(Sheet sheet, int rowNum,
                                 String id,
                                 String targetNodeType,
                                 String condition,
                                 String transformJs,
                                 String importPrerequisite,
                                 String classPrerequisite,
                                 String methodPrerequisite) {
        Row row = sheet.createRow(rowNum);
        row.createCell(0).setCellValue(id);
        row.createCell(1).setCellValue(targetNodeType);
        row.createCell(2).setCellValue(condition);
        row.createCell(3).setCellValue(transformJs);
        row.createCell(4).setCellValue(importPrerequisite);
        row.createCell(5).setCellValue(classPrerequisite);
        row.createCell(6).setCellValue(methodPrerequisite);
    }
}
