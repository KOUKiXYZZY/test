package kouki.convert;

import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;
import kouki.symboltable.SymbolTableListener;
import kouki.symboltable.java8.Java8Lexer;
import kouki.symboltable.java8.Java8Parser;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.TokenStreamRewriter;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * リスナーベースの Java コード変換エンジン。
 * ListenerRule を使って、条件にマッチしたノードに対して変換操作を適用する。
 *
 * メソッド呼び出し系のノード(MethodInvocation系, Primary, Expression, Statement)を
 * 対象にしたルールだけを1回のパースで適用する。クラス宣言・メソッド宣言等の
 * 宣言系ノードを対象にしたルールはここでは適用しない。
 */
public class SourceConverter {

    /**
     * リスナーベースの変換を実行
     *
     * @param javaFile 入力Javaファイルのパス
     * @param rules 適用するリスナールール一覧(メソッド呼び出し系以外は無視される)
     * @return 変換後のJavaコード
     */
    public static String convert(Path javaFile, List<ListenerRule> rules) throws IOException {
        return convert(javaFile, rules, null);
    }

    /**
     * リスナーベースの変換を実行
     *
     * @param javaFile 入力Javaファイルのパス
     * @param rules 適用するリスナールール一覧(メソッド呼び出し系以外は無視される)
     * @param symbolsDbPath 事前に./gradlew symboltableで生成したSQLiteファイルのパス(省略可)。
     *                      指定すると、変換対象ファイル単体では解決できないレシーバ型
     *                      (別ファイルで定義されたクラスなど)のフォールバックとして使われる
     * @return 変換後のJavaコード
     */
    public static String convert(Path javaFile, List<ListenerRule> rules, String symbolsDbPath) throws IOException {
        CharStream input = CharStreams.fromPath(javaFile);
        Java8Lexer lexer = new Java8Lexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        Java8Parser parser = new Java8Parser(tokens);
        ParseTree tree = parser.compilationUnit();

        // レシーバの型解決(ctx.getReceiverType()等)のため、変換対象ファイル自身に対して
        // シンボルテーブル抽出を行い、TypeResolverを組み立てる。
        // symbolsDbPathが指定されていれば、そちらをフォールバックとして先に積んでおき、
        // 変換対象ファイル自身の抽出結果を後から積むことで、同名衝突時はファイル自身を優先する。
        List<SymbolEntry> entries = new ArrayList<>();
        List<TypeRelation> relations = new ArrayList<>();

        if (symbolsDbPath != null && !symbolsDbPath.isBlank()) {
            try {
                entries.addAll(SymbolDbLoader.loadEntries(symbolsDbPath));
                relations.addAll(SymbolDbLoader.loadRelations(symbolsDbPath));
            } catch (SQLException e) {
                System.err.println("symbols.db(" + symbolsDbPath + ")の読み込みに失敗したため、無視して続行します: "
                        + e.getMessage());
            }
        }

        SymbolTableListener symbolListener = new SymbolTableListener(javaFile.toString());
        new ParseTreeWalker().walk(symbolListener, tree);
        entries.addAll(symbolListener.getEntries());
        relations.addAll(symbolListener.getRelations());

        TypeResolver typeResolver = new TypeResolver(entries, relations);

        // メソッド呼び出し系のルールだけに絞る(クラス宣言/メソッド宣言等は対象外)
        List<ListenerRule> callRules = new ArrayList<>();
        for (ListenerRule rule : rules) {
            if (isCallLikeRule(rule)) {
                callRules.add(rule);
            }
        }

        TokenStreamRewriter rewriter = new TokenStreamRewriter(tokens);
        ListenerBasedRewriter listener = new ListenerBasedRewriter(rewriter, callRules, typeResolver);
        new ParseTreeWalker().walk(listener, tree);

        return rewriter.getText();
    }

    private static boolean isCallLikeRule(ListenerRule rule) {
        if (rule == null || rule.targetNodeType() == null || rule.targetNodeType().isBlank()) {
            return true;
        }

        String target = rule.targetNodeType().toLowerCase();
        return target.contains("methodinvocation")
                || target.contains("primary")
                || target.contains("expression")
                || target.contains("statement");
    }
}
