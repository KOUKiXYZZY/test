package kouki.convert;

import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * kouki.symboltable(./gradlew symboltable)が出力したSQLite(symbols / type_relations テーブル)を
 * 読み込み、TypeResolverに渡せる形(SymbolEntry / TypeRelation)に変換するクラス。
 *
 * 変換対象の1ファイルだけでは型解決できないケース(レシーバの型が別ファイルで定義されている等)を
 * 補うために、事前に生成しておいたプロジェクト全体のシンボルテーブルをフォールバックとして使う。
 */
public class SymbolDbLoader {

    public static List<SymbolEntry> loadEntries(String dbPath) throws SQLException {
        List<SymbolEntry> entries = new ArrayList<>();
        String sql = "SELECT kind, name, type, access_modifier, is_static, is_final, scope_path, line, file FROM symbols";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                entries.add(new SymbolEntry(
                        rs.getString("kind"),
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getString("access_modifier"),
                        rs.getInt("is_static") != 0,
                        rs.getInt("is_final") != 0,
                        rs.getString("scope_path"),
                        rs.getInt("line"),
                        rs.getString("file")
                ));
            }
        }
        return entries;
    }

    public static List<TypeRelation> loadRelations(String dbPath) throws SQLException {
        List<TypeRelation> relations = new ArrayList<>();
        String sql = "SELECT child_scope, relation, parent_type, line, file FROM type_relations";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                relations.add(new TypeRelation(
                        rs.getString("child_scope"),
                        rs.getString("relation"),
                        rs.getString("parent_type"),
                        rs.getInt("line"),
                        rs.getString("file")
                ));
            }
        }
        return relations;
    }
}
