package kouki.convert;

/**
 * transformJs(JavaScript)側から呼び出せる、コード挿入用のアクション集。
 * `ctx`(TransformationContext)経由でJSに公開される。
 *
 * ルール表の importPrerequisite/classPrerequisite/methodPrerequisite 列が
 * 「常に固定のテキストを、マッチしたノードの直近のファイル/クラス/メソッドに挿入する」
 * という静的な指定しかできないのに対し、これらのメソッドはJSのロジック内から
 * 条件付き・動的にコードを挿入したり、現在のメソッド以外の任意のメソッドを名指しで
 * 対象にしたり、対象のメソッドが無ければ新規作成したりできる。
 */
public interface TransformRuleActions {

    /**
     * ファイルの先頭(package文があればその直後)にコードを挿入する。
     * 同じテキストは同じファイル内で1回しか挿入されない。
     */
    void addImport(String code);

    /**
     * 現在マッチしているノードを囲む、最も近いクラスの本体の先頭にコードを挿入する。
     * 同じテキストは同じクラス内で1回しか挿入されない。
     */
    void addClassMember(String code);

    /**
     * 現在マッチしているノードを囲む、最も近いクラスの中から指定した名前のメソッドを探し、
     * その本体の先頭にコードを挿入する。同じテキストは同じメソッド内で1回しか挿入されない。
     * 指定した名前のメソッドが見つからない場合は何もせず、警告を出力する
     * (メソッドが無ければ作成もしたい場合は addMethodIfMissing を先に呼ぶこと)。
     */
    void addToMethod(String methodName, String code);

    /**
     * 現在マッチしているノードを囲む、最も近いクラスの中に指定した名前のメソッドが
     * 存在しなければ、与えたメソッド全体のソースコード(シグネチャ込み)をクラス本体の
     * 末尾に追加する。同じ名前のメソッドは同じクラス内で1回しか追加されない
     * (既に存在する場合も、ここで追加済みとして扱われる場合も、それ以降の呼び出しは無視される)。
     */
    void addMethodIfMissing(String methodName, String methodSource);
}
