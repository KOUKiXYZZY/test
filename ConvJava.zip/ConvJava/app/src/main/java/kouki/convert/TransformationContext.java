package kouki.convert;

import kouki.convert.Node.SourceNode;

/**
 * transformJs(JavaScript関数)から参照されるノード情報。
 * ロジックはすべてContextに共通実装されており、これは薄いサブクラス。
 */
public class TransformationContext extends Context {

    public TransformationContext(SourceNode node, TypeResolver typeResolver,
                                  String methodScope, String classScope, TransformRuleActions actions) {
        super(node, typeResolver, methodScope, classScope, actions);
    }
}
