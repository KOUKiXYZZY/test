package kouki.convert;

import java.util.Map;
import java.util.Optional;

import org.graalvm.polyglot.Value;
import org.graalvm.polyglot.proxy.ProxyExecutable;

public class TransformationEvaluator extends Evaluator {
    /**
     * 変換用のJavaScript("function transform(ctx, bindings) { ...; return ...; }")を実行し、
     * 置き換え後のテキストを返す。
     * 評価/実行に失敗した場合はnullを返す(呼び出し側でそのノードの置き換えをスキップする)。
     *
     * @param transformJs JavaScript関数定義（transformという名前の関数を定義していること）
     * @param ctx TransformationContext オブジェクト
     * @param bindings パターンマッチでキャプチャされた変数マップ
     * @param actions ctx.addImport()等から呼ばれる、コード挿入用のアクション集
     */
    public String transform(String transformJs, TransformationContext ctx, Map<String, String> bindings,
                             TransformRuleActions actions) {
        if (transformJs == null || transformJs.isBlank()) {
            return ctx.originalText();
        }

        ProxyExecutable addImport = args -> {
            if (args.length != 1 || !args[0].isString()) {
                throw new IllegalArgumentException("addImport() は1つの文字列引数を取る必要があります");
            }
            actions.addImport(args[0].asString());
            return null;
        };

        ProxyExecutable addClassMember = args -> {
            if (args.length != 1 || !args[0].isString()) {
                throw new IllegalArgumentException("addClassMember() は1つの文字列引数を取る必要があります");
            }
            actions.addClassMember(args[0].asString());
            return null;
        };

        ProxyExecutable addToMethod = args -> {
            if (args.length != 2 || !args[0].isString() || !args[1].isString()) {
                throw new IllegalArgumentException("addToMethod() は2つの文字列引数を取る必要があります");
            }
            actions.addToMethod(args[0].asString(), args[1].asString());
            return null;
        };

        ProxyExecutable addMethodIfMissing = args -> {
            if (args.length != 2 || !args[0].isString() || !args[1].isString()) {
                throw new IllegalArgumentException("addMethodIfMissing() は2つの文字列引数を取る必要があります");
            }
            actions.addMethodIfMissing(args[0].asString(), args[1].asString());
            return null;
        };

        putMember("ctx", ctx)
                .putMember("bindings", bindings)
                .putMember("addImport", addImport)
                .putMember("addClassMember", addClassMember)
                .putMember("addToMethod", addToMethod)
                .putMember("addMethodIfMissing", addMethodIfMissing);

        try {
            // 関数定義を評価したのち、定義された transform 関数自体を取得して呼び出す
            Optional<Value> optDefined = evaluate(transformJs + "\ntransform;");
            if (optDefined.isEmpty() || !optDefined.get().canExecute()) {
                System.err.println("transformJs は transform という名前の関数を定義する必要があります: " + transformJs);
                return null;
            }

            Value result = optDefined.get().execute(ctx, bindings);
            if (!result.isString()) {
                System.err.println("変換関数の戻り値が文字列ではありません: " + result);
                return null;
            }
            return result.asString();
        } catch (Exception e) {
            System.err.println("変換処理の実行に失敗しました: " + transformJs);
            System.err.println("エラー: " + e.getMessage());
            return null;
        }
    }
}
