package kouki.convert;

import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * シンボルテーブル情報(SymbolEntry/TypeRelation)を使って、変数やメソッド呼び出し結果の型を
 * ベストエフォートで解決するクラス。kouki.javacallgraph.CallResolver と同じ考え方を、
 * メソッドチェーン("a().b()")の戻り値型も追えるように拡張したもの。
 *
 * 解析対象外の型(外部ライブラリなど)に行き着いた時点で、それ以上は追わずnullを返す。
 */
public class TypeResolver {

    private static final int MAX_SUPERCLASS_HOPS = 20;

    // scopePath -> { 変数名 -> 型 } (フィールド/引数/ローカル変数)
    private final Map<String, Map<String, String>> variableTypesByScope = new HashMap<>();
    // クラスのscopePath -> { メソッド名 -> 戻り値型 }
    private final Map<String, Map<String, String>> methodReturnTypesByScope = new HashMap<>();
    // クラスの単純名 -> スコープパス
    private final Map<String, String> simpleNameToScope = new HashMap<>();
    // 子クラスのスコープパス -> 親クラスのスコープパス(EXTENDSのみ)
    private final Map<String, String> superClassOf = new HashMap<>();

    public TypeResolver(List<SymbolEntry> entries, List<TypeRelation> relations) {
        for (SymbolEntry e : entries) {
            switch (e.kind()) {
                case "FIELD", "PARAMETER", "LOCAL_VARIABLE" -> variableTypesByScope
                        .computeIfAbsent(e.scopePath(), k -> new HashMap<>())
                        .put(e.name(), e.type());
                case "METHOD" -> methodReturnTypesByScope
                        .computeIfAbsent(e.scopePath(), k -> new HashMap<>())
                        .put(e.name(), e.type());
                case "CLASS", "INTERFACE", "ENUM" -> {
                    String fullScope = e.scopePath().isEmpty() ? e.name() : e.scopePath() + "." + e.name();
                    simpleNameToScope.put(e.name(), fullScope);
                }
                default -> {
                    // CONSTRUCTOR/ENUM_CONSTANTは型解決には使わない
                }
            }
        }
        for (TypeRelation r : relations) {
            if (!r.relation().equals("EXTENDS")) {
                continue;
            }
            String superScope = lookupScope(r.parentType());
            if (superScope != null) {
                superClassOf.put(r.childScope(), superScope);
            }
        }
    }

    /**
     * クラスの単純名("Animal")またはFQCN("pkg.Animal")からスコープパスを探す。
     * ローカルファイル自身のシンボルは単純名で書かれている(SymbolTableListenerは
     * importを解決しないため)一方、symbols.dbから読み込んだデータはFQCN解決済みの
     * ことがある(kouki.symboltable.Mainの二パス目で解決されるため)。どちらの形式でも
     * 解決できるよう、まずそのままの文字列で探し、見つからなければFQCNの最後のセグメント
     * (単純名)で探し直す。
     */
    private String lookupScope(String typeName) {
        if (typeName == null) {
            return null;
        }
        String scope = simpleNameToScope.get(typeName);
        if (scope != null) {
            return scope;
        }
        return simpleNameToScope.get(lastSegment(typeName));
    }

    // ローカル変数/引数(methodScope) -> フィールド(classScope) の順で変数の宣言型を探す
    public String resolveVariableType(String varName, String methodScope, String classScope) {
        Map<String, String> localVars = variableTypesByScope.get(methodScope);
        if (localVars != null && localVars.containsKey(varName)) {
            return localVars.get(varName);
        }
        Map<String, String> fields = variableTypesByScope.get(classScope);
        if (fields != null && fields.containsKey(varName)) {
            return fields.get(varName);
        }
        return null;
    }

    // クラスのスコープパスから、継承チェーン(EXTENDS)を辿りながらメソッドの戻り値型を探す
    public String resolveMethodReturnType(String classScope, String methodName) {
        String current = classScope;
        for (int hops = 0; current != null && hops < MAX_SUPERCLASS_HOPS; hops++) {
            Map<String, String> methods = methodReturnTypesByScope.get(current);
            if (methods != null && methods.containsKey(methodName)) {
                return methods.get(methodName);
            }
            current = superClassOf.get(current);
        }
        return null;
    }

    /**
     * レシーバ式("obj", "this", "obj.foo()", "a().b()" など)を再帰的に解決し、その式が
     * 表す値の型名を返す。外部ライブラリの型に行き着いた場合や、解決できない場合はnull。
     */
    public String resolveExpressionType(String expr, String methodScope, String classScope) {
        if (expr == null || expr.isBlank()) {
            return null;
        }
        expr = expr.trim();

        if (expr.equals("this")) {
            return classScope == null ? null : lastSegment(classScope);
        }

        if (expr.endsWith(")")) {
            // x.y(...) 形式(メソッド呼び出し)として分解する
            int openParen = matchingOpenParen(expr);
            if (openParen < 0) {
                return null;
            }
            String beforeParen = expr.substring(0, openParen);
            int lastDot = topLevelLastDot(beforeParen);
            String methodName = lastDot >= 0 ? beforeParen.substring(lastDot + 1) : beforeParen;
            String receiverExpr = lastDot >= 0 ? beforeParen.substring(0, lastDot) : null;

            String receiverType = receiverExpr == null
                    ? (classScope == null ? null : lastSegment(classScope))
                    : resolveExpressionType(receiverExpr, methodScope, classScope);
            if (receiverType == null) {
                return null;
            }
            String receiverClassScope = lookupScope(receiverType);
            if (receiverClassScope == null) {
                // 解析対象外の型(外部ライブラリなど)。これ以上は追えない
                return null;
            }
            return resolveMethodReturnType(receiverClassScope, methodName);
        }

        // x.y 形式(フィールドアクセス)、または単純な変数名
        int lastDot = topLevelLastDot(expr);
        if (lastDot < 0) {
            return resolveVariableType(expr, methodScope, classScope);
        }
        String receiverExpr = expr.substring(0, lastDot);
        String fieldName = expr.substring(lastDot + 1);
        String receiverType = resolveExpressionType(receiverExpr, methodScope, classScope);
        if (receiverType == null) {
            return null;
        }
        String receiverClassScope = lookupScope(receiverType);
        if (receiverClassScope == null) {
            return null;
        }
        Map<String, String> fields = variableTypesByScope.get(receiverClassScope);
        return fields == null ? null : fields.get(fieldName);
    }

    private static String lastSegment(String scopePath) {
        int lastDot = scopePath.lastIndexOf('.');
        return lastDot < 0 ? scopePath : scopePath.substring(lastDot + 1);
    }

    // 文字列末尾の')'に対応する開き'('の位置を見つける(ネスト考慮)
    private static int matchingOpenParen(String s) {
        int depth = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == ')') {
                depth++;
            } else if (c == '(') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    // ジェネリクス/括弧のネストを考慮して、トップレベル(深さ0)の最後の'.'を探す
    private static int topLevelLastDot(String s) {
        int depth = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == ')' || c == '>') {
                depth++;
            } else if (c == '(' || c == '<') {
                depth--;
            } else if (c == '.' && depth == 0) {
                return i;
            }
        }
        return -1;
    }
}
