package kouki.javacallgraph;

// コールグラフの1本の辺(呼び出し関係)を表すレコード。
// callerScope: 呼び出している側のメソッド/コンストラクタのスコープパス(例: "com.example.Sample.main")
// calleeName: 呼び出されているメソッドの名前(単純名のみ)
// receiverExpr: 呼び出しの「左側」のテキスト(例: "obj.foo()" なら "obj")。
//               bareな呼び出し(例: "foo()")ならnull。これを使って、CallResolverが
//               シンボルテーブルの変数宣言情報と組み合わせ、呼び出し先のクラスを推測する
public record CallEdge(
        String callerScope,
        String calleeName,
        String receiverExpr,
        int line,
        String file
) {
}
