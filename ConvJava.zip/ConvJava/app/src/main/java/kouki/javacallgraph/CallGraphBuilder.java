package kouki.javacallgraph;

import kouki.symboltable.java8.Java8Lexer;
import kouki.symboltable.java8.Java8Parser;
import kouki.symboltable.SymbolTableListener;
import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

// 指定したJavaファイル(またはディレクトリ配下の*.java)を解析し、
// メソッド呼び出しの関係(コールグラフ)を抽出してSQLiteに保存するCLI。
//
// 呼び出し先がどのクラスのメソッドかをできるだけ推測するため、
// kouki.antlrjava8symboltable パッケージのシンボルテーブル抽出も同じファイルに対して実行し、
// 変数/フィールドの宣言型をCallResolverに渡している。
public class CallGraphBuilder {

    public static void usage() {
        System.err.println("Usage: CallGraphBuilder <path-to-java-file-or-directory> [sqlite-db-path]");
    }

    public static void main(String[] args) throws IOException, SQLException {
        if (args.length < 1) {
            usage();
            System.exit(1);
        }

        String sourcePath = args[0];
        String dbPath = args.length >= 2 ? args[1] : "callgraph.db";

        List<Path> javaFiles = collectJavaFiles(Path.of(sourcePath));

        List<CallEdge> allEdges = new ArrayList<>();
        List<SymbolEntry> allEntries = new ArrayList<>();
        List<TypeRelation> allRelations = new ArrayList<>();
        for (Path javaFile : javaFiles) {
            ParseTree tree = parseTree(javaFile);

            CallGraphListener callListener = new CallGraphListener(javaFile.toString());
            new ParseTreeWalker().walk(callListener, tree);
            allEdges.addAll(callListener.getEdges());

            SymbolTableListener symbolListener = new SymbolTableListener(javaFile.toString());
            new ParseTreeWalker().walk(symbolListener, tree);
            allEntries.addAll(symbolListener.getEntries());
            allRelations.addAll(symbolListener.getRelations());
        }

        List<ResolvedCallEdge> resolvedEdges = CallResolver.resolve(allEntries, allRelations, allEdges);

        resolvedEdges.forEach(e -> System.out.printf("%-45s -> %-20s resolvedClass=%-30s line=%d file=%s%n",
                e.callerScope(), e.calleeName(), e.resolvedClass() == null ? "?" : e.resolvedClass(),
                e.line(), e.file()));

        CallGraphStore.save(dbPath, resolvedEdges);
        long resolvedCount = resolvedEdges.stream().filter(e -> e.resolvedClass() != null).count();
        System.out.println("Saved " + resolvedEdges.size() + " call edges (" + resolvedCount
                + " resolved) from " + javaFiles.size() + " file(s) to " + dbPath);
    }

    // ディレクトリなら配下の*.javaを再帰的に列挙し、ファイルならそれ自身だけを返す
    private static List<Path> collectJavaFiles(Path path) throws IOException {
        if (Files.isDirectory(path)) {
            try (Stream<Path> walk = Files.walk(path)) {
                return walk.filter(p -> Files.isRegularFile(p) && p.toString().endsWith(".java"))
                        .sorted(Comparator.naturalOrder())
                        .toList();
            }
        }
        return List.of(path);
    }

    private static ParseTree parseTree(Path javaFile) throws IOException {
        CharStream input = CharStreams.fromPath(javaFile);
        Java8Lexer lexer = new Java8Lexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        Java8Parser parser = new Java8Parser(tokens);
        return parser.compilationUnit();
    }
}
