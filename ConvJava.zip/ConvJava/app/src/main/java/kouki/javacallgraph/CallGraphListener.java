package kouki.javacallgraph;

import kouki.symboltable.java8.Java8Parser;
import kouki.symboltable.java8.Java8ParserBaseListener;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

// ANTLRの構文木を巡回しながら、「どのメソッド/コンストラクタの中で、どのメソッドが呼ばれているか」を集める。
// クラス/メソッドに入る(enter)たびにスコープをスタックに積み、抜ける(exit)たびに降ろすのは
// SymbolTableListenerと同じ考え方(スコープパスを組み立てるため)。
public class CallGraphListener extends Java8ParserBaseListener {

    private final String file;
    private final List<CallEdge> edges = new ArrayList<>();
    private final Deque<String> scope = new ArrayDeque<>();
    // 現在メソッド/コンストラクタの中にいるかどうか(中でなければ呼び出しを記録しない)
    private int methodOrConstructorDepth = 0;

    public CallGraphListener(String file) {
        this.file = file;
    }

    public List<CallEdge> getEdges() {
        return edges;
    }

    private String currentScope() {
        return String.join(".", scope);
    }

    @Override
    public void enterPackageDeclaration(Java8Parser.PackageDeclarationContext ctx) {
        scope.addLast(ctx.packageName().getText());
    }

    @Override
    public void enterNormalClassDeclaration(Java8Parser.NormalClassDeclarationContext ctx) {
        scope.addLast(ctx.Identifier().getText());
    }

    @Override
    public void exitNormalClassDeclaration(Java8Parser.NormalClassDeclarationContext ctx) {
        scope.removeLast();
    }

    @Override
    public void enterNormalInterfaceDeclaration(Java8Parser.NormalInterfaceDeclarationContext ctx) {
        scope.addLast(ctx.Identifier().getText());
    }

    @Override
    public void exitNormalInterfaceDeclaration(Java8Parser.NormalInterfaceDeclarationContext ctx) {
        scope.removeLast();
    }

    @Override
    public void enterEnumDeclaration(Java8Parser.EnumDeclarationContext ctx) {
        scope.addLast(ctx.Identifier().getText());
    }

    @Override
    public void exitEnumDeclaration(Java8Parser.EnumDeclarationContext ctx) {
        scope.removeLast();
    }

    @Override
    public void enterMethodDeclaration(Java8Parser.MethodDeclarationContext ctx) {
        scope.addLast(ctx.methodHeader().methodDeclarator().Identifier().getText());
        methodOrConstructorDepth++;
    }

    @Override
    public void exitMethodDeclaration(Java8Parser.MethodDeclarationContext ctx) {
        methodOrConstructorDepth--;
        scope.removeLast();
    }

    @Override
    public void enterInterfaceMethodDeclaration(Java8Parser.InterfaceMethodDeclarationContext ctx) {
        scope.addLast(ctx.methodHeader().methodDeclarator().Identifier().getText());
        methodOrConstructorDepth++;
    }

    @Override
    public void exitInterfaceMethodDeclaration(Java8Parser.InterfaceMethodDeclarationContext ctx) {
        methodOrConstructorDepth--;
        scope.removeLast();
    }

    @Override
    public void enterConstructorDeclaration(Java8Parser.ConstructorDeclarationContext ctx) {
        scope.addLast(ctx.constructorDeclarator().simpleTypeName().getText());
        methodOrConstructorDepth++;
    }

    @Override
    public void exitConstructorDeclaration(Java8Parser.ConstructorDeclarationContext ctx) {
        methodOrConstructorDepth--;
        scope.removeLast();
    }

    // "foo()" のように式の先頭に来る単純な呼び出しは、methodInvocationではなく
    // methodInvocation_lfno_primary というルールになる(Java8文法が左再帰除去のため細かく分かれている)
    @Override
    public void enterMethodInvocation(Java8Parser.MethodInvocationContext ctx) {
        String calleeName = ctx.methodName() != null ? ctx.methodName().getText()
                : ctx.Identifier() != null ? ctx.Identifier().getText() : null;
        String receiver;
        if (ctx.expressionName() != null) {
            receiver = ctx.expressionName().getText();
        } else if (ctx.primary() != null) {
            receiver = ctx.primary().getText();
        } else if (ctx.typeName() != null) {
            receiver = ctx.typeName().getText();
        } else if (ctx.methodName() == null) {
            // 残るのは 'super'.foo(...) や TypeName.super.foo(...) の形
            receiver = "super";
        } else {
            receiver = null;
        }
        recordCallIfInsideMethod(calleeName, receiver, ctx.getStart().getLine());
    }

    @Override
    public void enterMethodInvocation_lfno_primary(Java8Parser.MethodInvocation_lfno_primaryContext ctx) {
        String calleeName = ctx.methodName() != null ? ctx.methodName().getText()
                : ctx.Identifier() != null ? ctx.Identifier().getText() : null;
        String receiver;
        if (ctx.expressionName() != null) {
            receiver = ctx.expressionName().getText();
        } else if (ctx.typeName() != null) {
            receiver = ctx.typeName().getText();
        } else if (ctx.methodName() == null) {
            receiver = "super";
        } else {
            receiver = null;
        }
        recordCallIfInsideMethod(calleeName, receiver, ctx.getStart().getLine());
    }

    private void recordCallIfInsideMethod(String calleeName, String receiver, int line) {
        if (calleeName == null || methodOrConstructorDepth == 0) {
            // フィールド初期化子やstaticイニシャライザ内の呼び出しなど、
            // メソッド/コンストラクタの外で起きている呼び出しは対象外にしている
            return;
        }
        edges.add(new CallEdge(currentScope(), calleeName, receiver, line, file));
    }
}
