package kouki.javacallgraph;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

// コールグラフの辺(ResolvedCallEdge)をSQLiteの call_edges テーブルに保存するクラス
public class CallGraphStore {

    private static final String CREATE_TABLE = """
            CREATE TABLE IF NOT EXISTS call_edges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                caller_scope TEXT NOT NULL,
                callee_name TEXT NOT NULL,
                resolved_class TEXT,
                line INTEGER,
                file TEXT NOT NULL
            )
            """;

    private static final String INSERT = """
            INSERT INTO call_edges (caller_scope, callee_name, resolved_class, line, file)
            VALUES (?, ?, ?, ?, ?)
            """;

    public static void save(String dbPath, List<ResolvedCallEdge> edges) throws SQLException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)) {
            try (Statement st = conn.createStatement()) {
                st.execute(CREATE_TABLE);
            }
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(INSERT)) {
                for (ResolvedCallEdge edge : edges) {
                    ps.setString(1, edge.callerScope());
                    ps.setString(2, edge.calleeName());
                    ps.setString(3, edge.resolvedClass());
                    ps.setInt(4, edge.line());
                    ps.setString(5, edge.file());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            conn.commit();
        }
    }
}
