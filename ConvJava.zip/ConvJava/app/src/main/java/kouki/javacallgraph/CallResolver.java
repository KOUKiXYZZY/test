package kouki.javacallgraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;

// シンボルテーブル(SymbolEntry/TypeRelationの一覧)を使って、コールグラフの各辺(CallEdge)の
// 「呼び出し先がどのクラスのメソッドか」をできるだけ推測するクラス。
//
// 推測のやり方は2つだけ:
//   1. レシーバーが無いbareな呼び出し(例: "foo()", "this.foo()")は、
//      呼び出し元のクラス、またその親クラス(extendsを辿る)でそのメソッド名が
//      宣言されていれば、見つかったクラスだと推測する
//   2. レシーバーがある呼び出し(例: "obj.foo()")は、objが呼び出し元のローカル変数/引数/
//      フィールドとして宣言されていれば、その宣言された型を呼び出し先のクラスとみなす
//
// どちらにも当たらない場合(チェーン呼び出しの結果に対する呼び出しや、解析対象外のクラスを
// 継承している場合など)は resolvedClass を null のままにする。
// 型解析エンジンではないので、ここまでがベストエフォートの限界。
public class CallResolver {

    // 継承チェーンを辿る際、循環参照などで無限ループにならないようにする上限
    private static final int MAX_SUPERCLASS_HOPS = 20;

    public static List<ResolvedCallEdge> resolve(List<SymbolEntry> entries, List<TypeRelation> relations,
                                                  List<CallEdge> edges) {
        // scopePath -> { 変数名 -> 型 } (フィールド/引数/ローカル変数をまとめて入れる)
        Map<String, Map<String, String>> variableTypesByScope = new HashMap<>();
        // メソッド名 -> そのメソッドを宣言しているクラスのスコープパス一覧
        Map<String, Set<String>> methodOwners = new HashMap<>();
        // クラスの単純名 -> そのクラスの完全なスコープパス(extends句は単純名で書かれているため、
        // それをスコープパスに変換するために使う)
        Map<String, String> simpleNameToScope = new HashMap<>();

        for (SymbolEntry e : entries) {
            switch (e.kind()) {
                case "FIELD", "PARAMETER", "LOCAL_VARIABLE" -> variableTypesByScope
                        .computeIfAbsent(e.scopePath(), k -> new HashMap<>())
                        .put(e.name(), e.type());
                case "METHOD" -> methodOwners
                        .computeIfAbsent(e.name(), k -> new HashSet<>())
                        .add(e.scopePath());
                case "CLASS", "INTERFACE", "ENUM" -> {
                    String fullScope = e.scopePath().isEmpty() ? e.name() : e.scopePath() + "." + e.name();
                    simpleNameToScope.put(e.name(), fullScope);
                }
                default -> {
                    // CONSTRUCTOR/ENUM_CONSTANTは今回の推測には使わない
                }
            }
        }

        // 子クラスのスコープパス -> 親クラスのスコープパス(EXTENDSのみ。解析対象に無いクラスを
        // 継承している場合は、対応するスコープパスが見つからないのでマップに入らない)
        Map<String, String> superClassOf = new HashMap<>();
        for (TypeRelation r : relations) {
            if (!r.relation().equals("EXTENDS")) {
                continue;
            }
            String superScope = simpleNameToScope.get(r.parentType());
            if (superScope != null) {
                superClassOf.put(r.childScope(), superScope);
            }
        }

        List<ResolvedCallEdge> resolved = new ArrayList<>();
        for (CallEdge edge : edges) {
            String resolvedClass = resolveOne(edge, variableTypesByScope, methodOwners, superClassOf);
            resolved.add(new ResolvedCallEdge(edge.callerScope(), edge.calleeName(), resolvedClass,
                    edge.line(), edge.file()));
        }
        return resolved;
    }

    private static String resolveOne(CallEdge edge, Map<String, Map<String, String>> variableTypesByScope,
                                      Map<String, Set<String>> methodOwners, Map<String, String> superClassOf) {
        String callerClassScope = parentScope(edge.callerScope());

        if (edge.receiverExpr() == null || edge.receiverExpr().equals("this")) {
            // bareな呼び出し、または this.foo(...) :
            // 呼び出し元のクラスから順に、親クラスを辿りながらメソッドの宣言場所を探す
            String currentClass = callerClassScope;
            for (int hops = 0; currentClass != null && hops < MAX_SUPERCLASS_HOPS; hops++) {
                Set<String> owners = methodOwners.get(edge.calleeName());
                if (owners != null && owners.contains(currentClass)) {
                    return currentClass;
                }
                currentClass = superClassOf.get(currentClass);
            }
            return null;
        }

        // レシーバーがローカル変数/引数(呼び出し元メソッドのスコープ)として宣言されていないか確認する
        Map<String, String> localVars = variableTypesByScope.get(edge.callerScope());
        if (localVars != null && localVars.containsKey(edge.receiverExpr())) {
            return localVars.get(edge.receiverExpr());
        }

        // 次に、呼び出し元クラスのフィールドとして宣言されていないか確認する
        Map<String, String> classFields = variableTypesByScope.get(callerClassScope);
        if (classFields != null && classFields.containsKey(edge.receiverExpr())) {
            return classFields.get(edge.receiverExpr());
        }

        return null;
    }

    // "com.example.Sample.main" -> "com.example.Sample" のように、スコープパスの末尾1段を取り除く
    private static String parentScope(String scopePath) {
        int lastDot = scopePath.lastIndexOf('.');
        return lastDot < 0 ? "" : scopePath.substring(0, lastDot);
    }
}
