package kouki.javacallgraph;

// CallResolverが、シンボルテーブルの情報を使って呼び出し先のクラスをできるだけ推測した後の辺。
// resolvedClass: 呼び出し先が属していると推測されるクラスのスコープパス(推測できなければnull)
public record ResolvedCallEdge(
        String callerScope,
        String calleeName,
        String resolvedClass,
        int line,
        String file
) {
}
