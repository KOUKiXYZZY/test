package kouki.symboltable.DataEntities;

public record SymbolEntry(
        String kind,
        String name,
        String type,
        String accessModifier,
        boolean isStatic,
        boolean isFinal,
        String scopePath,
        int line,
        String file
) {
}
