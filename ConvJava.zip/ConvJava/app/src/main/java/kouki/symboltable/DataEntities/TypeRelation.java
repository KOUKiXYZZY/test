package kouki.symboltable.DataEntities;

// クラス/インターフェース間の継承関係(extends, implements)を表すレコード
public record TypeRelation(
        String childScope,
        String relation,
        String parentType,
        int line,
        String file
) {
}
