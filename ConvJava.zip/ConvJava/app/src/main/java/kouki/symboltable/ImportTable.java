package kouki.symboltable;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

// 1ファイル分の package文 / import文 をまとめたもの。型名解決(FQCN化)に使う。
public class ImportTable {

    // package文が無いファイルは無名パッケージなので空文字
    private String packageName = "";

    // 単純名 -> 完全限定名 (import java.util.List; なら "List" -> "java.util.List")
    private final Map<String, String> singleTypeImports = new HashMap<>();

    // ワイルドカードimportのパッケージ名一覧 (import java.util.*; なら "java.util")
    private final List<String> wildcardPackages = new ArrayList<>();

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public void addSingleTypeImport(String fqcn) {
        String simpleName = fqcn.substring(fqcn.lastIndexOf('.') + 1);
        singleTypeImports.put(simpleName, fqcn);
    }

    public void addWildcardPackage(String packageName) {
        wildcardPackages.add(packageName);
    }

    public Map<String, String> getSingleTypeImports() {
        return singleTypeImports;
    }

    public List<String> getWildcardPackages() {
        return wildcardPackages;
    }
}
