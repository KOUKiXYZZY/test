package kouki.symboltable;

import kouki.symboltable.java8.Java8Lexer;
import kouki.symboltable.java8.Java8Parser;
import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Stream;

public class Main {
    public static void usage() {
        System.err.println("Usage: java8SourceReader <path-to-java-file-or-directory | path-to-jar | fully.qualified.ClassName> "
                + "[sqlite-db-path] [append|overwrite]");
        System.err.println("  path: .javaファイル/ディレクトリ、.jarファイル、または既にクラスパス上にある");
        System.err.println("        完全修飾クラス名(例: java.util.ArrayList)のいずれかを指定できる。");
        System.err.println("        jar/クラス名の場合はソースが無くてもリフレクションでシンボルを抽出する。");
        System.err.println("  mode: append(デフォルト)は既存のsymbols.dbに追記する。");
        System.err.println("        overwriteは書き込み前に既存の内容を空にする。");
        System.err.println("        同じdbに対してソース解析→jar解析の順にappendで2回実行すると、");
        System.err.println("        1つのsymbols.dbにプロジェクト自身と外部ライブラリの型情報をまとめられる。");
    }

    public static void main(String[] args) throws IOException, SQLException {
        if (args.length < 1) {
            usage();
            System.exit(1);
        }

        String sourcePath = args[0];
        String dbPath = args.length >= 2 ? args[1] : "symbols.db";
        String modeArg = args.length >= 3 ? args[2] : "append";
        boolean overwrite = parseMode(modeArg);

        List<SymbolEntry> allEntries = new ArrayList<>();
        List<TypeRelation> allRelations = new ArrayList<>();
        int unitCount;

        InputKind kind = classifyInput(sourcePath);
        switch (kind) {
            case JAR -> unitCount = analyzeJar(Path.of(sourcePath), allEntries, allRelations);
            case CLASS_NAME -> unitCount = analyzeClassName(sourcePath, allEntries, allRelations);
            default -> unitCount = analyzeJavaSource(Path.of(sourcePath), allEntries, allRelations);
        }

        allEntries.forEach(e -> System.out.printf("%-15s %-20s %-30s %-17s %-7s %-6s scope=%-20s line=%d file=%s%n",
                e.kind(), e.name(), e.type() == null ? "" : e.type(),
                e.accessModifier() == null ? "" : e.accessModifier(),
                e.isStatic() ? "static" : "", e.isFinal() ? "final" : "",
                e.scopePath(), e.line(), e.file()));
        allRelations.forEach(r -> System.out.printf("%-15s %s -> %s (line %d)%n",
                r.relation(), r.childScope(), r.parentType(), r.line()));

        SymbolStore.save(dbPath, allEntries, overwrite);
        TypeRelationStore.save(dbPath, allRelations, overwrite);
        System.out.println("Saved " + allEntries.size() + " symbols and " + allRelations.size()
                + " relations from " + unitCount + " " + kind.unitLabel() + " to " + dbPath
                + " (mode=" + (overwrite ? "overwrite" : "append") + ")");
    }

    private enum InputKind {
        JAVA_SOURCE, JAR, CLASS_NAME;

        String unitLabel() {
            return switch (this) {
                case JAVA_SOURCE -> "file(s)";
                case JAR -> "class(es) in jar";
                case CLASS_NAME -> "class";
            };
        }
    }

    private static InputKind classifyInput(String sourcePath) {
        Path path = Path.of(sourcePath);
        if (Files.isRegularFile(path) && sourcePath.endsWith(".jar")) {
            return InputKind.JAR;
        }
        if (Files.exists(path)) {
            return InputKind.JAVA_SOURCE;
        }
        // 存在するファイル/ディレクトリではない -> クラスパス上の完全修飾クラス名として扱う
        return InputKind.CLASS_NAME;
    }

    private static boolean parseMode(String modeArg) {
        String normalized = modeArg.trim().toLowerCase();
        if (normalized.equals("overwrite")) {
            return true;
        }
        if (!normalized.equals("append")) {
            System.err.println("警告: 不明なmode \"" + modeArg + "\" はappendとして扱います");
        }
        return false;
    }

    // ===== .javaソース解析(既存の二パス方式) =====

    private static int analyzeJavaSource(Path sourceRoot, List<SymbolEntry> allEntries,
                                          List<TypeRelation> allRelations) throws IOException {
        List<Path> javaFiles = collectJavaFiles(sourceRoot);

        // 1パス目: 全ファイルをパースするだけ。型名の解決はまだしない
        // (他のファイルで定義されたクラスをimportしている場合があるので、
        //  全ファイルを読み終えてからでないと正しく解決できない)
        List<SymbolTableListener> listeners = new ArrayList<>();
        for (Path javaFile : javaFiles) {
            listeners.add(parseFile(javaFile));
        }

        // 解析対象全体で「単純名 -> 完全限定名」の候補を集めたレジストリを作る
        // (同じ単純名のトップレベルクラスが複数ファイルにあると候補が複数になることもある)
        Map<String, List<String>> registry = buildTopLevelTypeRegistry(listeners);

        // 2パス目: 各ファイルごとのimport文を使って、型名をできるだけFQCNに解決する
        for (SymbolTableListener listener : listeners) {
            TypeNameResolver resolver = new TypeNameResolver(listener.getImportTable(), registry);
            for (SymbolEntry e : listener.getEntries()) {
                allEntries.add(new SymbolEntry(e.kind(), e.name(), resolver.resolve(e.type()),
                        e.accessModifier(), e.isStatic(), e.isFinal(), e.scopePath(), e.line(), e.file()));
            }
            for (TypeRelation r : listener.getRelations()) {
                allRelations.add(new TypeRelation(r.childScope(), r.relation(),
                        resolver.resolve(r.parentType()), r.line(), r.file()));
            }
        }

        return javaFiles.size();
    }

    // ディレクトリなら配下の*.javaを再帰的に列挙し、ファイルならそれ自身だけを返す
    private static List<Path> collectJavaFiles(Path path) throws IOException {
        if (Files.isDirectory(path)) {
            try (Stream<Path> walk = Files.walk(path)) {
                return walk.filter(p -> Files.isRegularFile(p) && p.toString().endsWith(".java"))
                        .sorted(Comparator.naturalOrder())
                        .toList();
            }
        }
        return List.of(path);
    }

    // 1ファイルを字句解析→構文解析し、構文木をリスナーで巡回してシンボルを集める
    private static SymbolTableListener parseFile(Path javaFile) throws IOException {
        CharStream input = CharStreams.fromPath(javaFile);
        Java8Lexer lexer = new Java8Lexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        Java8Parser parser = new Java8Parser(tokens);

        // compilationUnit はJavaファイル1つ分(package文〜末尾まで)に対応する開始ルール
        ParseTree tree = parser.compilationUnit();

        SymbolTableListener listener = new SymbolTableListener(javaFile.toString());
        new ParseTreeWalker().walk(listener, tree);
        return listener;
    }

    // トップレベルのクラス/インターフェース/enumだけを集め、単純名からFQCNを引けるレジストリを作る
    // (トップレベルかどうかは、scope_pathがそのファイルのpackage名と一致するかで判定する。
    //  ネストしたクラス(例: Sample.Greeter)はscope_pathがさらに深くなるので対象外)
    private static Map<String, List<String>> buildTopLevelTypeRegistry(List<SymbolTableListener> listeners) {
        Map<String, List<String>> registry = new HashMap<>();
        for (SymbolTableListener listener : listeners) {
            String packageName = listener.getImportTable().getPackageName();

            for (SymbolEntry e : listener.getEntries()) {
                boolean isType = e.kind().equals("CLASS") || e.kind().equals("INTERFACE") || e.kind().equals("ENUM");

                if (isType && e.scopePath().equals(packageName)) {
                    String fqcn = packageName.isEmpty() ? e.name() : packageName + "." + e.name();

                    registry.computeIfAbsent(e.name(), k -> new ArrayList<>()).add(fqcn);
                }
            }
        }
        return registry;
    }

    // ===== jarファイル解析(リフレクション) =====

    private static int analyzeJar(Path jarPath, List<SymbolEntry> allEntries,
                                   List<TypeRelation> allRelations) throws IOException {
        List<String> classNames = new ArrayList<>();
        try (JarFile jarFile = new JarFile(jarPath.toFile())) {
            Enumeration<JarEntry> jarEntries = jarFile.entries();
            while (jarEntries.hasMoreElements()) {
                JarEntry entry = jarEntries.nextElement();
                String name = entry.getName();
                if (!name.endsWith(".class") || name.equals("module-info.class") || name.endsWith("package-info.class")) {
                    continue;
                }
                classNames.add(name.substring(0, name.length() - ".class".length()).replace('/', '.'));
            }
        }

        int loadedCount = 0;
        URL jarUrl = jarPath.toUri().toURL();
        try (URLClassLoader classLoader = new URLClassLoader(new URL[]{jarUrl}, Main.class.getClassLoader())) {
            for (String className : classNames) {
                try {
                    Class<?> clazz = Class.forName(className, false, classLoader);
                    allEntries.addAll(ReflectionSymbolExtractor.extractEntries(clazz, jarPath.toString()));
                    allRelations.addAll(ReflectionSymbolExtractor.extractRelations(clazz, jarPath.toString()));
                    loadedCount++;
                } catch (Throwable e) {
                    // 依存クラスがクラスパス上に無い等でロードに失敗するクラスは、警告してスキップする
                    System.err.println("警告: " + className + " のロードに失敗したためスキップします: " + e);
                }
            }
        }
        return loadedCount;
    }

    // ===== 単一クラス名解析(リフレクション) =====

    private static int analyzeClassName(String className, List<SymbolEntry> allEntries,
                                         List<TypeRelation> allRelations) {
        try {
            Class<?> clazz = Class.forName(className);
            allEntries.addAll(ReflectionSymbolExtractor.extractEntries(clazz, "reflection:" + className));
            allRelations.addAll(ReflectionSymbolExtractor.extractRelations(clazz, "reflection:" + className));
            return 1;
        } catch (ClassNotFoundException e) {
            System.err.println("クラス " + className + " が見つかりません"
                    + "(このツール自身のクラスパス上に無いクラスは、代わりに.jarファイルを指定してください): " + e);
            return 0;
        }
    }
}
