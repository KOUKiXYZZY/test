package kouki.symboltable;

import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * .javaソースではなく、コンパイル済みのClassオブジェクト(jarファイルやclasspath上のクラス)から
 * リフレクションでシンボル情報を抽出するクラス。
 *
 * SymbolTableListener(ソース解析)と同じ形(SymbolEntry/TypeRelation)で結果を返すため、
 * TypeResolverや既存のSymbolStore/TypeRelationStoreにそのまま渡せる。これにより、
 * プロジェクト自身のソースだけでなく、JDKや外部ライブラリ(servlet-api等)のjarに含まれる
 * クラスの型情報も symbols.db に取り込んで、getReceiverType()等のフォールバック解決に使える。
 *
 * 制約(ベストエフォート):
 *   - オーバーロードされたメソッドは、同名のうち最後に見つかったものの戻り値型だけが残る
 *     (SymbolEntry/TypeResolverがメソッド名だけをキーにしているため。ソース解析側も同じ制限)
 *   - コンストラクタ/合成メソッド(ブリッジメソッド等)は対象外
 *   - private/package-privateメンバーも一応含める(継承チェーン解決に使うことがあるため)。
 *     除外したい場合は呼び出し側でフィルタすること
 */
public class ReflectionSymbolExtractor {

    public static List<SymbolEntry> extractEntries(Class<?> clazz, String sourceLabel) {
        List<SymbolEntry> entries = new ArrayList<>();

        String packageName = clazz.getPackageName();
        String className = clazz.getSimpleName();
        String classScope = packageName.isEmpty() ? className : packageName + "." + className;

        String kind = clazz.isInterface() ? "INTERFACE" : clazz.isEnum() ? "ENUM" : "CLASS";
        int classModifiers = clazz.getModifiers();
        entries.add(new SymbolEntry(kind, className, null, accessModifierOf(classModifiers),
                Modifier.isStatic(classModifiers), Modifier.isFinal(classModifiers),
                packageName, 0, sourceLabel));

        for (Field field : clazz.getDeclaredFields()) {
            if (field.isSynthetic()) {
                continue;
            }
            int mod = field.getModifiers();
            entries.add(new SymbolEntry("FIELD", field.getName(), typeNameOf(field.getType()),
                    accessModifierOf(mod), Modifier.isStatic(mod), Modifier.isFinal(mod),
                    classScope, 0, sourceLabel));
        }

        for (Method method : clazz.getDeclaredMethods()) {
            if (method.isSynthetic() || method.isBridge()) {
                continue;
            }
            int mod = method.getModifiers();
            entries.add(new SymbolEntry("METHOD", method.getName(), typeNameOf(method.getReturnType()),
                    accessModifierOf(mod), Modifier.isStatic(mod), Modifier.isFinal(mod),
                    classScope, 0, sourceLabel));
        }

        return entries;
    }

    public static List<TypeRelation> extractRelations(Class<?> clazz, String sourceLabel) {
        List<TypeRelation> relations = new ArrayList<>();

        String packageName = clazz.getPackageName();
        String className = clazz.getSimpleName();
        String classScope = packageName.isEmpty() ? className : packageName + "." + className;

        Class<?> superclass = clazz.getSuperclass();
        if (superclass != null && superclass != Object.class) {
            relations.add(new TypeRelation(classScope, "EXTENDS", typeNameOf(superclass), 0, sourceLabel));
        }

        for (Class<?> iface : clazz.getInterfaces()) {
            relations.add(new TypeRelation(classScope, "IMPLEMENTS", typeNameOf(iface), 0, sourceLabel));
        }

        return relations;
    }

    private static String typeNameOf(Class<?> type) {
        String canonical = type.getCanonicalName();
        return canonical != null ? canonical : type.getName();
    }

    private static String accessModifierOf(int modifiers) {
        if (Modifier.isPublic(modifiers)) {
            return "public";
        }
        if (Modifier.isProtected(modifiers)) {
            return "protected";
        }
        if (Modifier.isPrivate(modifiers)) {
            return "private";
        }
        return "package-private";
    }
}
