package kouki.symboltable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import kouki.symboltable.DataEntities.SymbolEntry;

// 抽出したシンボル一覧(SymbolEntry)をSQLiteの symbols テーブルに保存するクラス
public class SymbolStore {

    private static final String CREATE_TABLE = """
            CREATE TABLE IF NOT EXISTS symbols (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                name TEXT NOT NULL,
                type TEXT,
                access_modifier TEXT,
                is_static INTEGER NOT NULL,
                is_final INTEGER NOT NULL,
                scope_path TEXT,
                line INTEGER,
                file TEXT NOT NULL
            )
            """;

    private static final String INSERT = """
            INSERT INTO symbols (kind, name, type, access_modifier, is_static, is_final, scope_path, line, file)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

    /**
     * @param overwrite trueの場合、insertする前に既存の symbols テーブルの中身を全て削除する
     *                  (テーブル自体は再作成せず、DELETEで空にするだけ)。
     *                  falseの場合は常に追記(insert)する。
     */
    public static void save(String dbPath, List<SymbolEntry> entries, boolean overwrite) throws SQLException {
        // "jdbc:sqlite:ファイルパス" という形式のURLを渡すと、無ければ新規作成、あれば追記接続される
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)) {
            try (Statement st = conn.createStatement()) {
                st.execute(CREATE_TABLE);
                if (overwrite) {
                    st.execute("DELETE FROM symbols");
                }
            }
            // 1件ずつコミットすると遅いので、まとめてバッチ実行してから一回でコミットする
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(INSERT)) {
                for (SymbolEntry e : entries) {
                    ps.setString(1, e.kind());
                    ps.setString(2, e.name());
                    ps.setString(3, e.type());
                    ps.setString(4, e.accessModifier());
                    // SQLiteにboolean型は無いので0/1で保存する
                    ps.setInt(5, e.isStatic() ? 1 : 0);
                    ps.setInt(6, e.isFinal() ? 1 : 0);
                    ps.setString(7, e.scopePath());
                    ps.setInt(8, e.line());
                    ps.setString(9, e.file());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            conn.commit();
        }
    }
}
