package kouki.symboltable;

import kouki.symboltable.java8.Java8Parser;
import kouki.symboltable.java8.Java8ParserBaseListener;
import kouki.symboltable.DataEntities.SymbolEntry;
import kouki.symboltable.DataEntities.TypeRelation;

import org.antlr.v4.runtime.ParserRuleContext;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

// ANTLRの構文木を ParseTreeWalker で巡回する際に呼ばれるリスナー。
// クラス/メソッドなどに入る(enter)たびにスコープをスタックに積み、
// 抜ける(exit)たびに降ろすことで、入れ子になったスコープのパス(例: Sample.main)を組み立てる。
public class SymbolTableListener extends Java8ParserBaseListener {

    private static final List<String> ACCESS_KEYWORDS = List.of("public", "protected", "private");
    // public/protected/privateのどれも書かれていない場合、Javaの仕様上はパッケージプライベート扱いになる
    private static final String DEFAULT_ACCESS = "package-private";

    private final String file;
    private final List<SymbolEntry> entries = new ArrayList<>();
    private final List<TypeRelation> relations = new ArrayList<>();
    // このファイルのpackage文/import文を集めたもの。FQCN解決(TypeNameResolver)に使う
    private final ImportTable importTable = new ImportTable();
    // 現在どのクラス/メソッドの中にいるかを表すスタック(先頭から順にネストしている)
    private final Deque<String> scope = new ArrayDeque<>();

    public SymbolTableListener(String file) {
        this.file = file;
    }

    public List<SymbolEntry> getEntries() {
        return entries;
    }

    public List<TypeRelation> getRelations() {
        return relations;
    }

    public ImportTable getImportTable() {
        return importTable;
    }

    // スタックの中身を "Sample.main" のようにドット区切りでつなげる
    private String currentScope() {
        return String.join(".", scope);
    }

    private void pushScope(String name) {
        scope.addLast(name);
    }

    private void popScope() {
        scope.removeLast();
    }

    // static/finalを持たない種類(PARAMETER, ENUM_CONSTANT等)向けの簡易オーバーロード
    private void add(String kind, String name, String type, String accessModifier, int line) {
        add(kind, name, type, accessModifier, false, false, line);
    }

    private void add(String kind, String name, String type, String accessModifier,
                      boolean isStatic, boolean isFinal, int line) {
        entries.add(new SymbolEntry(kind, name, type, accessModifier, isStatic, isFinal,
                currentScope(), line, file));
    }

    // classModifier/fieldModifier等の修飾子一覧から public/protected/private のどれかを探す。
    // (文法上、修飾子はアノテーションも含むので順不同・複数あり得る)
    private static String accessModifierOf(List<? extends ParserRuleContext> modifiers) {
        for (ParserRuleContext modifier : modifiers) {
            String text = modifier.getText();
            if (ACCESS_KEYWORDS.contains(text)) {
                return text;
            }
        }
        return DEFAULT_ACCESS;
    }

    // 修飾子一覧の中に指定したキーワード(static, finalなど)が含まれているかを調べる
    private static boolean hasModifier(List<? extends ParserRuleContext> modifiers, String keyword) {
        for (ParserRuleContext modifier : modifiers) {
            if (modifier.getText().equals(keyword)) {
                return true;
            }
        }
        return false;
    }

    // package文があれば、それをスコープの一番外側として積んでおく
    // (package文が無いファイルは「無名パッケージ」扱いなので何もしない)
    @Override
    public void enterPackageDeclaration(Java8Parser.PackageDeclarationContext ctx) {
        String packageName = ctx.packageName().getText();
        pushScope(packageName);
        importTable.setPackageName(packageName);
    }

    // import文1つ1つ(import java.util.List; のような単一クラス指定)を記録する
    @Override
    public void enterSingleTypeImportDeclaration(Java8Parser.SingleTypeImportDeclarationContext ctx) {
        importTable.addSingleTypeImport(ctx.typeName().getText());
    }

    // ワイルドカードimport(import java.util.*; のようなパッケージ全体指定)を記録する
    @Override
    public void enterTypeImportOnDemandDeclaration(Java8Parser.TypeImportOnDemandDeclarationContext ctx) {
        importTable.addWildcardPackage(ctx.packageOrTypeName().getText());
    }

    @Override
    public void enterNormalClassDeclaration(Java8Parser.NormalClassDeclarationContext ctx) {
        String name = ctx.Identifier().getText();
        add("CLASS", name, null, accessModifierOf(ctx.classModifier()),
                hasModifier(ctx.classModifier(), "static"), hasModifier(ctx.classModifier(), "final"),
                ctx.getStart().getLine());
        pushScope(name);

        // extends(継承元クラス)とimplements(実装するインターフェース)を関係として記録する
        String childPath = currentScope();
        if (ctx.superclass() != null) {
            String parent = ctx.superclass().classType().getText();
            relations.add(new TypeRelation(childPath, "EXTENDS", parent, ctx.getStart().getLine(), file));
        }
        if (ctx.superinterfaces() != null) {
            for (var interfaceType : ctx.superinterfaces().interfaceTypeList().interfaceType()) {
                relations.add(new TypeRelation(childPath, "IMPLEMENTS", interfaceType.getText(),
                        ctx.getStart().getLine(), file));
            }
        }
    }

    @Override
    public void exitNormalClassDeclaration(Java8Parser.NormalClassDeclarationContext ctx) {
        popScope();
    }

    @Override
    public void enterNormalInterfaceDeclaration(Java8Parser.NormalInterfaceDeclarationContext ctx) {
        String name = ctx.Identifier().getText();
        // interfaceModifierにはfinalが無い(インターフェースはfinalにできない)のでisFinalは常にfalse
        add("INTERFACE", name, null, accessModifierOf(ctx.interfaceModifier()),
                hasModifier(ctx.interfaceModifier(), "static"), false, ctx.getStart().getLine());
        pushScope(name);

        // インターフェースは複数のインターフェースをextendsできる
        if (ctx.extendsInterfaces() != null) {
            String childPath = currentScope();
            for (var interfaceType : ctx.extendsInterfaces().interfaceTypeList().interfaceType()) {
                relations.add(new TypeRelation(childPath, "EXTENDS", interfaceType.getText(),
                        ctx.getStart().getLine(), file));
            }
        }
    }

    @Override
    public void exitNormalInterfaceDeclaration(Java8Parser.NormalInterfaceDeclarationContext ctx) {
        popScope();
    }

    @Override
    public void enterEnumDeclaration(Java8Parser.EnumDeclarationContext ctx) {
        String name = ctx.Identifier().getText();
        add("ENUM", name, null, accessModifierOf(ctx.classModifier()),
                hasModifier(ctx.classModifier(), "static"), hasModifier(ctx.classModifier(), "final"),
                ctx.getStart().getLine());
        pushScope(name);

        if (ctx.superinterfaces() != null) {
            String childPath = currentScope();
            for (var interfaceType : ctx.superinterfaces().interfaceTypeList().interfaceType()) {
                relations.add(new TypeRelation(childPath, "IMPLEMENTS", interfaceType.getText(),
                        ctx.getStart().getLine(), file));
            }
        }
    }

    @Override
    public void exitEnumDeclaration(Java8Parser.EnumDeclarationContext ctx) {
        popScope();
    }

    // enum定数(RED, GREEN, BLUE など)。フィールドやメソッドとは別の専用ルールなので個別に拾う
    @Override
    public void enterEnumConstant(Java8Parser.EnumConstantContext ctx) {
        String name = ctx.Identifier().getText();
        add("ENUM_CONSTANT", name, null, null, ctx.getStart().getLine());
    }

    @Override
    public void enterMethodDeclaration(Java8Parser.MethodDeclarationContext ctx) {
        String name = ctx.methodHeader().methodDeclarator().Identifier().getText();
        String returnType = ctx.methodHeader().result().getText();
        add("METHOD", name, returnType, accessModifierOf(ctx.methodModifier()),
                hasModifier(ctx.methodModifier(), "static"), hasModifier(ctx.methodModifier(), "final"),
                ctx.getStart().getLine());
        pushScope(name);
    }

    @Override
    public void exitMethodDeclaration(Java8Parser.MethodDeclarationContext ctx) {
        popScope();
    }

    // インターフェース内のメソッドは文法上 methodDeclaration とは別の
    // interfaceMethodDeclaration というルールになっているため、個別に処理する
    @Override
    public void enterInterfaceMethodDeclaration(Java8Parser.InterfaceMethodDeclarationContext ctx) {
        String name = ctx.methodHeader().methodDeclarator().Identifier().getText();
        String returnType = ctx.methodHeader().result().getText();
        // インターフェースのメソッドは修飾子を省略しても暗黙的にpublicになる仕様なので補正する
        String access = accessModifierOf(ctx.interfaceMethodModifier());
        access = access.equals(DEFAULT_ACCESS) ? "public" : access;
        // interfaceMethodModifierにはfinalが無いのでisFinalは常にfalse
        add("METHOD", name, returnType, access,
                hasModifier(ctx.interfaceMethodModifier(), "static"), false, ctx.getStart().getLine());
        pushScope(name);
    }

    @Override
    public void exitInterfaceMethodDeclaration(Java8Parser.InterfaceMethodDeclarationContext ctx) {
        popScope();
    }

    @Override
    public void enterConstructorDeclaration(Java8Parser.ConstructorDeclarationContext ctx) {
        String name = ctx.constructorDeclarator().simpleTypeName().getText();
        add("CONSTRUCTOR", name, null, accessModifierOf(ctx.constructorModifier()), ctx.getStart().getLine());
        pushScope(name);
    }

    @Override
    public void exitConstructorDeclaration(Java8Parser.ConstructorDeclarationContext ctx) {
        popScope();
    }

    @Override
    public void enterFieldDeclaration(Java8Parser.FieldDeclarationContext ctx) {
        String type = ctx.unannType().getText();
        String access = accessModifierOf(ctx.fieldModifier());
        boolean isStatic = hasModifier(ctx.fieldModifier(), "static");
        boolean isFinal = hasModifier(ctx.fieldModifier(), "final");
        // "int a, b;" のように1つの宣言で複数の変数を定義できるため、1つずつ登録する
        for (Java8Parser.VariableDeclaratorContext vd : ctx.variableDeclaratorList().variableDeclarator()) {
            String name = vd.variableDeclaratorId().Identifier().getText();
            add("FIELD", name, type, access, isStatic, isFinal, vd.getStart().getLine());
        }
    }

    @Override
    public void enterFormalParameter(Java8Parser.FormalParameterContext ctx) {
        String type = ctx.unannType().getText();
        String name = ctx.variableDeclaratorId().Identifier().getText();
        // 引数にはアクセス修飾子・staticという概念が無いのでアクセス修飾子はnull、staticは常にfalse。
        // ただしfinal引数("final int x")は書けるのでvariableModifierから判定する
        add("PARAMETER", name, type, null, false, hasModifier(ctx.variableModifier(), "final"),
                ctx.getStart().getLine());
    }

    @Override
    public void enterLocalVariableDeclaration(Java8Parser.LocalVariableDeclarationContext ctx) {
        String type = ctx.unannType().getText();
        boolean isFinal = hasModifier(ctx.variableModifier(), "final");
        for (Java8Parser.VariableDeclaratorContext vd : ctx.variableDeclaratorList().variableDeclarator()) {
            String name = vd.variableDeclaratorId().Identifier().getText();
            // ローカル変数にもアクセス修飾子・staticという概念は無いのでnull/false。finalだけ書ける
            add("LOCAL_VARIABLE", name, type, null, false, isFinal, vd.getStart().getLine());
        }
    }
}
