package kouki.symboltable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

// クラス図上の単純な型名(例: "List<String>")をできるだけ完全限定名(FQCN)に変換するクラス。
// クラスパス上の実際のjarやjdkは見ていないので、あくまで
// 「import文 / 同じ解析対象内のクラス / よく使うjava.langのクラス」から推測できる範囲。
// 解決できない場合は元の単純名のまま返す。
public class TypeNameResolver {

    private static final Set<String> PRIMITIVES = Set.of(
            "int", "long", "short", "byte", "char", "boolean", "float", "double", "void");

    // java.lang は import 不要で使えるため、よく使われるクラスをあらかじめ知っておく
    // (網羅はしていないので、ここに無いjava.langクラスは解決できない)
    private static final Set<String> JAVA_LANG_COMMON = Set.of(
            "Object", "String", "StringBuilder", "StringBuffer", "CharSequence",
            "Integer", "Long", "Short", "Byte", "Character", "Boolean", "Float", "Double", "Number",
            "Math", "System", "Thread", "Runnable", "Class", "Enum", "Record",
            "Exception", "RuntimeException", "Error", "Throwable",
            "Comparable", "Iterable", "AutoCloseable", "Cloneable",
            "Override", "Deprecated", "SuppressWarnings", "FunctionalInterface");

    private final ImportTable importTable;
    private final Map<String, List<String>> registry;

    public TypeNameResolver(ImportTable importTable, Map<String, List<String>> registry) {
        this.importTable = importTable;
        this.registry = registry;
    }

    // 配列("[]")やジェネリクス("<...>")を含む型表記全体を解決する
    public String resolve(String rawType) {
        if (rawType == null) {
            return null;
        }
        String type = rawType.trim();

        // 末尾の配列記号 "[]" は一旦剥がして、最後に付け直す
        StringBuilder arraySuffix = new StringBuilder();
        while (type.endsWith("[]")) {
            arraySuffix.append("[]");
            type = type.substring(0, type.length() - 2).trim();
        }

        String resolved = resolveGenericOrSimple(type);
        return resolved + arraySuffix;
    }

    private String resolveGenericOrSimple(String type) {
        int ltIndex = type.indexOf('<');
        if (ltIndex < 0 || !type.endsWith(">")) {
            return resolveSimpleName(type);
        }

        String baseName = type.substring(0, ltIndex);
        String argsPart = type.substring(ltIndex + 1, type.length() - 1);

        List<String> resolvedArgs = new ArrayList<>();
        for (String arg : splitTopLevelCommas(argsPart)) {
            resolvedArgs.add(resolveTypeArgument(arg.trim()));
        }

        return resolveSimpleName(baseName) + "<" + String.join(", ", resolvedArgs) + ">";
    }

    // ワイルドカード型引数 ("? extends Foo" / "? super Foo" / "?") を扱う
    private String resolveTypeArgument(String arg) {
        if (arg.equals("?")) {
            return arg;
        }
        if (arg.startsWith("? extends ")) {
            return "? extends " + resolve(arg.substring("? extends ".length()));
        }
        if (arg.startsWith("? super ")) {
            return "? super " + resolve(arg.substring("? super ".length()));
        }
        return resolve(arg);
    }

    // ジェネリクスの入れ子("Map<String, List<Integer>>"など)を考慮して、
    // トップレベルのカンマだけで分割する
    private static List<String> splitTopLevelCommas(String s) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '<') {
                depth++;
            } else if (c == '>') {
                depth--;
            } else if (c == ',' && depth == 0) {
                parts.add(s.substring(start, i));
                start = i + 1;
            }
        }
        parts.add(s.substring(start));
        return parts;
    }

    // ジェネリクスを含まない単純な型名1つを解決する
    private String resolveSimpleName(String name) {
        name = name.trim();

        if (name.contains(".") || PRIMITIVES.contains(name)) {
            // 既に完全限定名、またはプリミティブ型はそのまま
            return name;
        }

        String singleImport = importTable.getSingleTypeImports().get(name);
        if (singleImport != null) {
            return singleImport;
        }

        List<String> candidates = registry.get(name);
        if (candidates != null && !candidates.isEmpty()) {
            // 同じパッケージ内のクラスを優先する。複数候補がある場合は先頭を採用(ベストエフォート)
            String samePackage = importTable.getPackageName().isEmpty()
                    ? name
                    : importTable.getPackageName() + "." + name;
            if (candidates.contains(samePackage)) {
                return samePackage;
            }
            return candidates.get(0);
        }

        if (JAVA_LANG_COMMON.contains(name)) {
            return "java.lang." + name;
        }

        if (importTable.getWildcardPackages().size() == 1) {
            // ワイルドカードimportが1つだけなら、そこに属すると推測する(確証は無い)
            return importTable.getWildcardPackages().get(0) + "." + name;
        }

        // 解決できなかった場合は単純名のまま返す
        return name;
    }
}
