package kouki.symboltable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import kouki.symboltable.DataEntities.TypeRelation;

// クラス/インターフェース間の継承関係(TypeRelation)をSQLiteの type_relations テーブルに保存するクラス
public class TypeRelationStore {

    // child_scope: 継承する側(子)のスコープパス。 relation: EXTENDS or IMPLEMENTS。
    // parent_type: 継承元/実装先の型名
    private static final String CREATE_TABLE = """
            CREATE TABLE IF NOT EXISTS type_relations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                child_scope TEXT NOT NULL,
                relation TEXT NOT NULL,
                parent_type TEXT NOT NULL,
                line INTEGER,
                file TEXT NOT NULL
            )
            """;

    private static final String INSERT = """
            INSERT INTO type_relations (child_scope, relation, parent_type, line, file)
            VALUES (?, ?, ?, ?, ?)
            """;

    /**
     * @param overwrite trueの場合、insertする前に既存の type_relations テーブルの中身を全て削除する。
     *                  falseの場合は常に追記(insert)する。
     */
    public static void save(String dbPath, List<TypeRelation> relations, boolean overwrite) throws SQLException {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)) {
            try (Statement st = conn.createStatement()) {
                st.execute(CREATE_TABLE);
                if (overwrite) {
                    st.execute("DELETE FROM type_relations");
                }
            }
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(INSERT)) {
                for (TypeRelation r : relations) {
                    ps.setString(1, r.childScope());
                    ps.setString(2, r.relation());
                    ps.setString(3, r.parentType());
                    ps.setInt(4, r.line());
                    ps.setString(5, r.file());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            conn.commit();
        }
    }
}
