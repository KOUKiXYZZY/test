# 変換ルール表(.xlsx)の書き方

`kouki.convert.Main`(`./gradlew convert --args="<source.java> <rules.xlsx> [output.java] [symbols.db]"`)が
読み込むルール表の形式と、`transformJs`列で使えるJavaScript APIをまとめたもの。

サンプルは `rules/sample_rules.xlsx`(`./gradlew sampleruletable --args="rules/sample_rules.xlsx"` で再生成可能。
生成元は `app/src/main/java/kouki/convert/SampleRuleTableGenerator.java`)。

## 列構成（0-indexed、1行目はヘッダー）

| # | 列名 | 内容 |
|---|------|------|
| 0 | id | ルールID(任意の文字列。ログ出力で使われる) |
| 1 | targetNodeType | 対象ノード型の部分文字列(例: `"MethodInvocationContext"`)。実際のノードのクラス名(`ctx.getClass().getSimpleName()`)に**部分文字列として含まれていれば**マッチする |
| 2 | condition | JavaScript条件式。trueを返したら変換を適用する。空なら常にtrue |
| 3 | transformJs | 変換用のJavaScript関数。`function transform(ctx, bindings) { ...; return "置き換え後のテキスト"; }`という形式 |
| 4 | importPrerequisite | ファイルの先頭(`package`文の直後)に挿入する前提コード(あれば)。import文向け |
| 5 | classPrerequisite | 現在のクラス本体の先頭に挿入する前提コード(あれば)。フィールド宣言向け |
| 6 | methodPrerequisite | 現在のメソッド本体の先頭に挿入する前提コード(あれば)。ローカル変数宣言向け |

4〜6列は**同時に複数指定できる**(例: importとクラスフィールドを1つのルールで一緒に追加する)。
以前は前提コード列が1つで、挿入位置(`insertPosition`)を別列で指定する方式だったため、
importとCLASS_STARTを両方やりたい場合にルールを2つに分ける必要があったが、
挿入位置ごとに列を分けたことで1ルールにまとめられるようになった。

## targetNodeTypeの注意点

ANTLRの左再帰除去により、同じ「メソッド呼び出し」でも構文上の位置によって異なるノード型になる。

- `foo()`(レシーバ省略) → `MethodInvocation_lfno_primaryContext`
- `obj.foo()`(式の途中からの継続) → `MethodInvocation_lf_primaryContext`
- それ以外の文脈 → `MethodInvocationContext`

3つすべてに当てたい場合は `targetNodeType` を `"MethodInvocation"` のように短くする(部分文字列マッチなので3種類とも引っかかる)。

なお、`NormalClassDeclarationContext` / `MethodDeclarationContext` を対象にしたルールは
**現状リスナー側にフックが無いため発火しない**(クラス宣言・メソッド宣言の単位で条件評価される仕組みは未実装)。
今動くのはメソッド呼び出し(`MethodInvocation*`)・式(`Expression`)・文(`Statement`)・`Primary`の各ノードのみ。

## 前提コードの挿入位置(3種類)

- `importPrerequisite` — ファイルの先頭(`package`文があればその直後)に**ファイルにつき1回だけ**挿入
- `classPrerequisite` — 現在のクラス本体の先頭(`{`の直後)に、**同じクラスにつき1回だけ**挿入
- `methodPrerequisite` — 現在のメソッド本体の先頭に、**同じメソッドにつき1回だけ**挿入

同じテキストが複数のメソッド呼び出しにマッチしても、列(挿入位置)ごとに重複なく1回だけ挿入される。

## condition / transformJs から呼べるJava API(`ctx` = TransformationContext)

| メソッド | 戻り値 | 説明 |
|---|---|---|
| `ctx.originalText()` / `ctx.getText()` | String | マッチしたノードの元のソーステキスト |
| `ctx.getNodeType()` | String | ノードのクラス名(`MethodInvocationContext`等) |
| `ctx.getLine()` | int | ノードの行番号 |
| `ctx.getClassName()` | String | このノードを囲む最も近いクラス/インターフェース/enumの名前 |
| `ctx.getMethodName()` | String | このノードを囲む最も近いメソッドの名前 |
| `ctx.getMethodSignature()` | String | このノードを囲む最も近いメソッドのシグネチャ部分のテキスト |
| `ctx.extractMethodName()` | String | `obj.foo(...)` / `foo(...)` から `"foo"` を取り出す |
| `ctx.extractReceiver()` | String or null | `obj.foo(...)` の `"obj"` 部分。`this.foo(...)` も `"this"` を返す。レシーバ無しは `null` |
| `ctx.extractArguments()` | **Java List\<String\>** | `foo(a, b, c)` → `["a", "b", "c"]` |
| `ctx.reconstructWithArguments(args)` | String | 与えた引数リストで括弧の中身だけ差し替えた呼び出しテキストを返す |
| `ctx.getReceiverType()` | String or null | レシーバの型をベストエフォートで解決(下記参照) |
| `ctx.getVariableType(expr)` | String or null | 任意の変数名/式の型をベストエフォートで解決 |
| `ctx.addImport(code)` | void | ファイルの先頭にコードを挿入する(下記「transformJsから動的にコードを挿入する」参照) |
| `ctx.addClassMember(code)` | void | 現在のクラス本体の先頭にコードを挿入する |
| `ctx.addToMethod(methodName, code)` | void | 指定した名前のメソッドの本体先頭にコードを挿入する |
| `ctx.addMethodIfMissing(methodName, methodSource)` | void | 指定した名前のメソッドが無ければ、丸ごとクラスに追加する |

`bindings`は将来のパターンマッチ用の予約引数(現在は空のMap)。

### `getReceiverType()` / `getVariableType()` の挙動

シンボルテーブル(ローカル変数・引数・フィールド・メソッドの戻り値型と`extends`関係)を使って、
レシーバ式の型をベストエフォートで解決する。

- レシーバ省略(`foo()`)・`this.foo()` → 現在のクラス名を返す
- `obj.foo()` → `obj`がローカル変数/引数/フィールドとして宣言されていれば、その型を返す
- `a().b()` のようなメソッドチェーンも、`a()`の戻り値型を解析対象の中から探して再帰的に解決する
- 解析対象外の型(外部ライブラリ等)に行き着いた時点で、それ以上は追わず`null`を返す

### ファイルをまたいだ型解決(symbols.db)

`getReceiverType()`/`getVariableType()`は、デフォルトでは**変換対象の1ファイル自身**から抽出した
シンボルテーブルしか見ない。そのため、レシーバの宣言クラス(またはその継承元)が**別ファイル**に
あると解決できないことがある。

例: `samples/UseDog.java`の`d.describe()`は、`d`の型`Dog`自体は同じスコープのローカル変数なので
わかるが、`describe()`メソッドは`Dog`ではなく**別ファイル**`samples/Animal.java`の親クラス`Animal`
で定義されているため、`UseDog.java`単体のシンボルテーブルだけでは戻り値型(`String`)まで辿れない。

これを解決するには、事前にプロジェクト全体のシンボルテーブルをSQLiteに作っておき、`convert`タスクの
4番目の引数として渡す。

```
./gradlew symboltable --args="samples symbols.db"
./gradlew convert --args="samples/UseDog.java rules/sample_rules.xlsx output.java symbols.db"
```

`symbols.db`を渡すと、その内容が変換対象ファイル自身のシンボルテーブルの**フォールバック**として
マージされる(同じ変数名/クラス名が両方にある場合は、変換対象ファイル自身のほうが優先される)。

**注意**: `symbols.db`は`kouki.symboltable.Main`がimportを解決した**FQCN(完全修飾名)**で型を
保存している(例: `String`ではなく`java.lang.String`)。一方、変換対象ファイル自身から直接抽出する
型は単純名のまま(import解決前)。`condition`/`transformJs`で型名を比較する際は、
完全一致ではなく`.endsWith('String')`のように緩く比較するか、両方の形を考慮すること。

## transformJsから動的にコードを挿入する(import/クラス/メソッド)

`importPrerequisite`/`classPrerequisite`/`methodPrerequisite`の3列は、ルールがマッチした時に
**常に同じ固定テキストを、マッチした場所の直近のファイル/クラス/メソッドに**挿入する、という
静的な指定しかできない。これに対して`transformJs`からは、以下の4つのメソッドを使って
**条件付き・動的に**コードを挿入したり、**現在のメソッド以外の任意のメソッドを名前で指定**したり、
**そのメソッドが無ければ新規作成**したりできる。

| メソッド | 用途 | 重複排除の単位 |
|---|---|---|
| `ctx.addImport(code)` | ファイルの先頭にimport文などを追加 | 同じテキストはファイルにつき1回 |
| `ctx.addClassMember(code)` | 現在のクラスにフィールド等を追加 | 同じテキストはクラスにつき1回 |
| `ctx.addToMethod(methodName, code)` | **名前で指定した**メソッドの先頭にコードを追加 | 同じテキストはそのメソッドにつき1回 |
| `ctx.addMethodIfMissing(methodName, methodSource)` | その名前のメソッドが無ければ、`methodSource`(シグネチャ込みの完全なメソッド定義)をクラスに追加 | 同じ名前のメソッドはクラスにつき1回だけ作成(既存メソッドがあれば何もしない) |

`addToMethod`の`methodName`は「今マッチしているノードを囲んでいるメソッド」である必要はなく、
**同じクラス内の任意のメソッド名**を指定できる。指定したメソッドが構文木上に存在しない場合は
警告を出して何もしないので、新規作成もしたい場合は先に`addMethodIfMissing`を呼ぶこと
(`addMethodIfMissing`で今まさに作成中のメソッドに対しても、同じ呼び出しの中で続けて
`addToMethod`できる)。

### 例: getParameter()が出てきたら、条件付きでimportを追加し、destroy()を確保してコードを足す

```js
function transform(ctx, bindings) {
    // レシーバの型による条件付きimport(静的な列では書けない)
    if (ctx.getReceiverType() === 'SampleApplet') {
        ctx.addImport('import java.util.logging.Logger;');
    }

    // クラスにdestroy()メソッドが無ければ作成する(既にあれば何もしない)
    ctx.addMethodIfMissing('destroy', 'public void destroy() {\n    }');

    // destroy()メソッド(今マッチしている呼び出しがあるinit()/paint()ではない)にコードを追加
    ctx.addToMethod('destroy', 'System.out.println("destroyed");');

    return ctx.originalText();
}
```

`rules/sample_rules.xlsx`の`rule_ensure_destroy_cleanup`が実物のサンプル。

### 注意点

- `addToMethod`/`addMethodIfMissing`は**現在マッチしているノードを囲む直近のクラス**(`NormalClassDeclarationContext`)が対象。ネストしたクラスやインターフェース/enumのメソッドは検索しない。
- `methodSource`はシグネチャから閉じ括弧`}`までの**完全な**メソッド定義を渡すこと(`addMethodIfMissing`はそのままクラス本体の末尾に挿入する)。
- `addToMethod`で追加するコードは、対象メソッドの本体の**先頭**に挿入される(末尾や任意の位置を指定することはできない)。

## ⚠️ JavaScript側でJavaのListを扱う際の注意

`extractArguments()`はJavaの`java.util.List<String>`をそのまま返す。GraalVMはJavaのコレクションを
**ネイティブJS配列に変換しない**ため、JS配列のメソッド(`.push()` `.slice()` `.join()` `.length`等)は使えない。
代わりにJavaの`List`のメソッドを使うこと。

| JS配列でやりたいこと | ❌ 使えない | ✅ 正しい書き方 |
|---|---|---|
| 末尾に追加 | `args.push(x)` | `args.add(x)` |
| 先頭/任意を削除 | `args.splice(i,1)` | `args.remove(i)` |
| 置き換え | `args[i] = x` | `args.set(i, x)` |
| 要素数 | `args.length` | `args.size()` |
| 文字列化して連結 | `args.join(', ')` | 自前でループして連結するか、`ctx.reconstructWithArguments(args)` を使う |

### 引数を追加する例

```js
function transform(ctx, bindings) {
    var args = ctx.extractArguments();
    args.add("\"default\"");
    return ctx.reconstructWithArguments(args);
}
```

### 引数を削除して別の引数を追加し、メソッド名やシグネチャ自体も変える例

メソッド名やレシーバも変えたい場合は`reconstructWithArguments`(括弧の中身だけ差し替え)が使えないので、
自分でテキストを組み立てる。

```js
function transform(ctx, bindings) {
    var args = ctx.extractArguments();
    args.remove(0);
    args.add("HttpServletResponse response");
    var joined = "";
    for (var i = 0; i < args.size(); i++) {
        if (i > 0) joined += ", ";
        joined += args.get(i);
    }
    return "void doPost(" + joined + ")";
}
```

## transformJsが失敗した場合

`transform`関数の実行中に例外が起きた場合や、`transform`という名前の関数が定義されていない場合は、
そのノードへの適用がスキップされ(置き換えは行われない)、標準エラー出力に警告が出る。
変換全体は中断されず、他のルール・他のノードの処理は継続する。

## conditionでよくある間違い

`ctx.getText()`が返すのはJavaの`String`だが、GraalVMはこれをJSのネイティブ文字列に変換するため、
**JSの`.includes()`を使う**(Javaの`.contains()`は使えない)。

```js
// ❌ ctx.getText().contains('getParameter')   -> TypeError
// ✅
ctx.getText().includes('getParameter')
```

`condition`の評価結果は最終的にJavaScriptのtruthy/falsyルールに沿ってboolean化される
(`null`/`undefined`/`0`/空文字列は偽、それ以外は真)。`a && b`の形の式は、`a`が偽だと
`false`ではなく`a`自身(例えば`null`)を返すというJSの仕様があるが、これは正しく偽として扱われるので
気にしなくてよい。ただし`getReceiverType()`がnullを返す可能性がある場合は、
`ctx.getReceiverType() !== null && ctx.getReceiverType().endsWith('String')`のように
明示的にnullチェックしてから文字列メソッドを呼ぶこと(nullに対して`.endsWith()`等を呼ぶと
TypeErrorになる)。
