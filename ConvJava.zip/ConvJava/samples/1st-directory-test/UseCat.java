public class UseCat {
    protected String name;

    public String sound() {
        return "Meow";
    }
}
