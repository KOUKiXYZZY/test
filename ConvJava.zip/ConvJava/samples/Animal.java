package kouki.antlrjava8symboltable.sample;

public abstract class Animal implements Comparable<Animal> {
    protected String name;

    public abstract String sound();

    @Override
    public int compareTo(Animal other) {
        return name.compareTo(other.name);
    }

    public String describe() {
        return name + " says " + sound();
    }
}

class Dog extends Animal {
    @Override
    public String sound() {
        return "Woof";
    }

    public void bark() {
        System.out.println(describe());
    }
}
