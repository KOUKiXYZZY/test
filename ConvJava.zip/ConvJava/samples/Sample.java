package kouki.antlrjava8symboltable.sample;

import java.util.List;


enum TestEnum {
    A, B, C
}

public class Sample {

    private int value;
    private List<String> tags;
    public static final String LABEL = "sample";
    private static int counter;

    public Sample(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    // English comment Test
    public void setValue(int value) {
        /** Test */
        this.value = value;
    }

    // 日本語のコメントテスト
    interface Greeter {
        /**
         * 挨拶を返す
         * @param name
         * @return
         */
        String greet(String name);
    }

    // あるクラスの中で定義されたenum
    enum Color {
        RED, GREEN, BLUE
    }

    public static void main(String[] args) {
        Sample s = new Sample(42);
        System.out.println(s.getValue());
    }
}
