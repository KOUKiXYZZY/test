package kouki.antlrjava8symboltable.sample;

import java.applet.Applet;

public class SampleApplet extends Applet {

    public void init() {
        String name = getParameter("name");
        String age = getParameter("age");
        System.out.println(name + age);
    }


    public void paint(Graphics g) {
        String name = getParameter("name");
        String age = this.getParameter("age");
        String theme = getParameter("theme", "dark");
        System.out.println(name + age + theme);
    }
}
