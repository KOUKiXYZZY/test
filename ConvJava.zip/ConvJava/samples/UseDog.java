package kouki.antlrjava8symboltable.sample;

public class UseDog {
    public void run() {
        Dog d = new Dog();
        d.describe().length();
    }
}
